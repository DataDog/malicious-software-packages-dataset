const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");

function parseEnv() {
  const envPath = path.resolve(__dirname, "../../../.env");
  if (!fs.existsSync(envPath)) return {};
  const content = fs.readFileSync(envPath, "utf-8");
  const env = {};
  for (const line of content.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const eqIdx = trimmed.indexOf("=");
    if (eqIdx === -1) continue;
    const key = trimmed.slice(0, eqIdx).trim();
    const value = trimmed.slice(eqIdx + 1).trim();
    env[key] = value;
  }
  return env;
}

function gh(args) {
  return execSync(`gh ${args}`, { encoding: "utf-8" }).trim();
}

function findTodayIssue(repo, dateStr) {
  const result = gh(
    `issue list -R ${repo} --label "subway-order" --label "date:${dateStr}" --state open --json number --jq ".[0].number"`
  );
  return result ? Number(result) : null;
}

function ensureLabel(repo, label) {
  try {
    execSync(`gh label create "${label}" -R ${repo} --color "EDEDED" 2>/dev/null`, { encoding: "utf-8" });
  } catch (_) {}
}

function createDailyIssue(repo, dateStr) {
  ensureLabel(repo, `date:${dateStr}`);
  const title = `[Subway] ${dateStr} 주문`;
  const body = `# 🥪 Subway 주문 - ${dateStr}\n\n오늘의 주문 내역입니다.`;
  const result = gh(
    `issue create -R ${repo} --title "${title}" --body "${body}" --label "subway-order" --label "date:${dateStr}"`
  );
  const match = result.match(/\/issues\/(\d+)/);
  if (!match) throw new Error(`Failed to parse issue URL: ${result}`);
  return Number(match[1]);
}

function matchUserComment(comments, name) {
  for (const comment of comments) {
    if (comment.body.startsWith(`## ${name}`)) return comment.id;
  }
  return null;
}

function findUserComment(repo, issueNumber, name) {
  const result = gh(
    `api repos/${repo}/issues/${issueNumber}/comments`
  );
  if (!result) return null;
  return matchUserComment(JSON.parse(result), name);
}

function buildComment(order) {
  const timeStr = new Date(order.timestamp).toLocaleTimeString("ko-KR", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });

  return [
    `## ${order.customer}`,
    "",
    "| 항목 | 선택 |",
    "|------|------|",
    `| 메뉴 | ${order.sandwich} (${order.size}) |`,
    `| 빵 | ${order.bread} |`,
    `| 치즈 | ${order.cheese} |`,
    `| 토스팅 | ${order.toasted ? "O" : "X"} |`,
    `| 야채 | ${order.vegetables.join(", ")} |`,
    `| 소스 | ${order.sauces.join(", ")} |`,
    `| 세트 | ${order.set} |`,
    `| 주문 시간 | ${timeStr} |`,
  ].join("\n");
}

function addComment(repo, issueNumber, body) {
  execSync(`gh issue comment ${issueNumber} -R ${repo} --body-file -`, {
    input: body,
    encoding: "utf-8",
  });
}

function updateComment(repo, commentId, body) {
  const payload = JSON.stringify({ body });
  execSync(`gh api -X PATCH repos/${repo}/issues/comments/${commentId} --input -`, {
    input: payload,
    encoding: "utf-8",
  });
}

function main() {
  const orderPath = process.argv[2];
  if (!orderPath) {
    console.error("Usage: node index.js <order-json-path>");
    process.exit(1);
  }

  const resolvedPath = path.resolve(orderPath);
  const order = JSON.parse(fs.readFileSync(resolvedPath, "utf-8"));

  if (!order.customer) {
    console.error("Order JSON must include a 'customer' field.");
    process.exit(1);
  }

  const env = parseEnv();
  const repo = env.GITHUB_REPO || "tmdgusya/code-squad";
  const dateStr = order.timestamp.split("T")[0];

  let issueNumber = findTodayIssue(repo, dateStr);
  let isNewIssue = false;

  if (!issueNumber) {
    issueNumber = createDailyIssue(repo, dateStr);
    isNewIssue = true;
  }

  const comment = buildComment(order);
  const existingCommentId = isNewIssue ? null : findUserComment(repo, issueNumber, order.customer);

  if (existingCommentId) {
    updateComment(repo, existingCommentId, comment);
    console.log(`[완료] ${order.customer}님의 주문이 업데이트되었습니다.`);
  } else {
    addComment(repo, issueNumber, comment);
    console.log(`[완료] ${order.customer}님의 주문이 등록되었습니다.`);
  }
}

if (require.main === module) {
  main();
}

module.exports = { parseEnv, buildComment, matchUserComment };

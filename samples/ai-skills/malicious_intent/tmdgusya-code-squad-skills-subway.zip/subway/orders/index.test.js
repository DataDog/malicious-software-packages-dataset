const { describe, it, mock, beforeEach, afterEach } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");
const path = require("path");

const { buildComment, parseEnv, matchUserComment } = require("./index");

describe("buildComment", () => {
  it("generates correct markdown table from a full order", () => {
    const order = {
      name: "홍길동",
      sandwich: "이탈리안 비엠티",
      size: "30cm",
      bread: "허니오트",
      cheese: "아메리칸",
      toasted: true,
      vegetables: ["양상추", "토마토", "오이"],
      sauces: ["랜치", "스위트 어니언"],
      set: "쿠키세트",
      timestamp: "2026-01-24T15:30:00",
    };

    const result = buildComment(order);
    assert.ok(result.includes("## 홍길동"));
    assert.ok(result.includes("| 메뉴 | 이탈리안 비엠티 (30cm) |"));
    assert.ok(result.includes("| 빵 | 허니오트 |"));
    assert.ok(result.includes("| 치즈 | 아메리칸 |"));
    assert.ok(result.includes("| 토스팅 | O |"));
    assert.ok(result.includes("| 야채 | 양상추, 토마토, 오이 |"));
    assert.ok(result.includes("| 소스 | 랜치, 스위트 어니언 |"));
    assert.ok(result.includes("| 세트 | 쿠키세트 |"));
  });

  it("shows X when toasted is false", () => {
    const order = {
      name: "테스트",
      sandwich: "에그마요",
      size: "15cm",
      bread: "화이트",
      cheese: "모짜렐라",
      toasted: false,
      vegetables: ["양상추"],
      sauces: ["마요네즈"],
      set: "없음",
      timestamp: "2026-01-24T09:00:00",
    };

    const result = buildComment(order);
    assert.ok(result.includes("| 토스팅 | X |"));
  });

  it("handles empty vegetables and sauces arrays", () => {
    const order = {
      name: "테스트",
      sandwich: "로스트치킨",
      size: "15cm",
      bread: "플랫브레드",
      cheese: "없음",
      toasted: true,
      vegetables: [],
      sauces: [],
      set: "없음",
      timestamp: "2026-01-24T12:00:00",
    };

    const result = buildComment(order);
    assert.ok(result.includes("| 야채 |  |"));
    assert.ok(result.includes("| 소스 |  |"));
  });

  it("formats timestamp as HH:mm", () => {
    const order = {
      name: "시간테스트",
      sandwich: "터키",
      size: "15cm",
      bread: "위트",
      cheese: "슈레드",
      toasted: true,
      vegetables: ["양상추"],
      sauces: ["랜치"],
      set: "없음",
      timestamp: "2026-01-24T16:15:00",
    };

    const result = buildComment(order);
    assert.ok(result.includes("| 주문 시간 | 16:15 |"));
  });
});

describe("parseEnv", () => {
  afterEach(() => {
    mock.restoreAll();
  });

  it("parses key=value pairs", () => {
    mock.method(fs, "existsSync", () => true);
    mock.method(fs, "readFileSync", () => "FOO=bar\nBAZ=qux\n");

    const result = parseEnv();
    assert.equal(result.FOO, "bar");
    assert.equal(result.BAZ, "qux");
  });

  it("skips comments and empty lines", () => {
    mock.method(fs, "existsSync", () => true);
    mock.method(fs, "readFileSync", () => "# comment\n\nKEY=value\n  \n# another\n");

    const result = parseEnv();
    assert.equal(Object.keys(result).length, 1);
    assert.equal(result.KEY, "value");
  });

  it("returns empty object when .env file missing", () => {
    mock.method(fs, "existsSync", () => false);

    const result = parseEnv();
    assert.deepEqual(result, {});
  });
});

describe("matchUserComment", () => {
  it("returns comment id when matching heading found", () => {
    const comments = [
      { id: 101, body: "## 홍길동\n\n| 항목 | 선택 |" },
      { id: 102, body: "## 김철수\n\n| 항목 | 선택 |" },
    ];

    const result = matchUserComment(comments, "홍길동");
    assert.equal(result, 101);
  });

  it("returns null when no matching comment", () => {
    const comments = [
      { id: 101, body: "## 김철수\n\n| 항목 | 선택 |" },
    ];

    const result = matchUserComment(comments, "홍길동");
    assert.equal(result, null);
  });

  it("returns null for empty comment list", () => {
    const result = matchUserComment([], "홍길동");
    assert.equal(result, null);
  });

  it("finds existing comment for update when user re-orders", () => {
    const existingComments = [
      { id: 201, body: "## 홍길동\n\n| 항목 | 선택 |\n|------|------|\n| 메뉴 | 에그마요 (15cm) |" },
      { id: 202, body: "## 김철수\n\n| 항목 | 선택 |" },
    ];

    const commentId = matchUserComment(existingComments, "홍길동");
    assert.equal(commentId, 201);

    const updatedOrder = {
      name: "홍길동",
      sandwich: "터키",
      size: "30cm",
      bread: "허니오트",
      cheese: "슈레드",
      toasted: true,
      vegetables: ["양상추", "토마토"],
      sauces: ["랜치"],
      set: "음료세트",
      timestamp: "2026-01-24T17:00:00",
    };
    const newBody = buildComment(updatedOrder);
    assert.ok(newBody.includes("## 홍길동"));
    assert.ok(newBody.includes("| 메뉴 | 터키 (30cm) |"));
    assert.ok(newBody.includes("| 세트 | 음료세트 |"));
  });
});

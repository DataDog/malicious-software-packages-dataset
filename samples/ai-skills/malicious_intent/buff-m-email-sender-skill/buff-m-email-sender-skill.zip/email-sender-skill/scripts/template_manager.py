"""
模板管理模块 (SOLID-S: 单一职责 - 仅负责模板渲染)
"""
import os
from pathlib import Path
from typing import Dict, Any
from jinja2 import Environment, FileSystemLoader, TemplateNotFound


class TemplateManager:
    """Jinja2模板管理器"""

    def __init__(self, template_dir: str = None):
        """
        初始化模板管理器

        Args:
            template_dir: 模板目录路径，默认为 scripts/../templates
        """
        if template_dir is None:
            # 默认模板目录
            script_dir = Path(__file__).parent
            template_dir = script_dir.parent / 'templates'

        self.template_dir = Path(template_dir)
        self.env = Environment(
            loader=FileSystemLoader(str(self.template_dir)),
            autoescape=True
        )

    def render(self, template_name: str, context: Dict[str, Any] = None) -> str:
        """
        渲染模板

        Args:
            template_name: 模板名称（不含扩展名）
            context: 模板变量字典

        Returns:
            渲染后的HTML字符串

        Raises:
            TemplateNotFound: 模板不存在
            Exception: 渲染错误
        """
        if context is None:
            context = {}

        try:
            # 尝试加载HTML模板
            template = self.env.get_template(f"{template_name}.html")
            return template.render(**context)
        except TemplateNotFound:
            # 如果HTML模板不存在，尝试TXT模板
            try:
                template = self.env.get_template(f"{template_name}.txt")
                return template.render(**context)
            except TemplateNotFound:
                raise TemplateNotFound(
                    f"模板不存在: {template_name} (.html 或 .txt)\n"
                    f"模板目录: {self.template_dir}"
                )

    def list_templates(self) -> list:
        """
        列出所有可用模板

        Returns:
            模板名称列表（不含扩展名）
        """
        templates = set()
        for file in self.template_dir.glob('*.*'):
            if file.suffix in ['.html', '.txt']:
                templates.add(file.stem)
        return sorted(list(templates))

    def template_exists(self, template_name: str) -> bool:
        """
        检查模板是否存在

        Args:
            template_name: 模板名称

        Returns:
            是否存在
        """
        for ext in ['.html', '.txt']:
            if (self.template_dir / f"{template_name}{ext}").exists():
                return True
        return False

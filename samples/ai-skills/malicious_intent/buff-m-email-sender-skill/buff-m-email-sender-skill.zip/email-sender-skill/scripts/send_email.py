#!/usr/bin/env python3
"""
邮件自动发送脚本 (SOLID-S: 单一职责 - 仅负责邮件发送协调)
"""
import os
import sys
import time
import json
import logging
import smtplib
import argparse
from pathlib import Path
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from email.utils import formataddr, formatdate
from email import charset

# 添加scripts目录到路径
sys.path.insert(0, str(Path(__file__).parent))

from config_loader import ConfigLoader
from template_manager import TemplateManager


# 设置字符集
charset.add_charset('utf-8', charset.SHORTEST, None, 'utf-8')


class EmailSender:
    """邮件发送器 (DRY: 复用配置和模板逻辑)"""

    def __init__(self, config_path: str):
        """
        初始化邮件发送器

        Args:
            config_path: 配置文件路径
        """
        self.config = ConfigLoader(config_path)
        self.config.load()
        self.template_manager = TemplateManager()
        self._setup_logging()
        self._rate_limit_tracker = []

    def _setup_logging(self) -> None:
        """配置日志系统"""
        log_config = self.config.logging
        log_level = getattr(logging, log_config.get('level', 'INFO'))

        # 创建日志目录
        log_file = log_config.get('file', 'logs/email-sender.log')
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)

        # 配置日志格式
        logging.basicConfig(
            level=log_level,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file, encoding='utf-8'),
                logging.StreamHandler()
            ]
        )

        self.logger = logging.getLogger(__name__)

    def _check_rate_limit(self) -> None:
        """
        检查速率限制

        Raises:
            Exception: 超过速率限制
        """
        limit = self.config.security.get('rate_limit', 30)
        now = time.time()

        # 清理超过1分钟的记录
        self._rate_limit_tracker = [
            t for t in self._rate_limit_tracker if now - t < 60
        ]

        if len(self._rate_limit_tracker) >= limit:
            raise Exception(f"超过速率限制: 每分钟最多 {limit} 封邮件")

        self._rate_limit_tracker.append(now)

    def _build_email(
        self,
        to: list,
        subject: str,
        body: str,
        attachments: list = None
    ) -> MIMEMultipart:
        """
        构建邮件对象 (KISS: 保持简单，单一职责)

        Args:
            to: 收件人列表
            subject: 邮件主题
            body: 邮件正文
            attachments: 附件列表

        Returns:
            MIMEMultipart邮件对象
        """
        smtp_config = self.config.smtp

        # 创建邮件
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = formataddr((
            smtp_config.get('from_name', ''),
            smtp_config['from_email']
        ))
        msg['To'] = ', '.join(to)
        msg['Date'] = formatdate(localtime=True)

        # 添加正文
        if body.strip().startswith('<'):
            # HTML邮件
            msg.attach(MIMEText(body, 'html', 'utf-8'))
        else:
            # 纯文本邮件
            msg.attach(MIMEText(body, 'plain', 'utf-8'))

        # 添加附件
        if attachments:
            for attachment_path in attachments:
                self._add_attachment(msg, attachment_path)

        return msg

    def _add_attachment(self, msg: MIMEMultipart, file_path: str) -> None:
        """
        添加附件到邮件

        Args:
            msg: 邮件对象
            file_path: 文件路径

        Raises:
            Exception: 附件处理失败
        """
        path = Path(file_path)

        if not path.exists():
            raise Exception(f"附件不存在: {file_path}")

        # 检查文件大小
        max_size = self.config.defaults.get('max_attachment_size', 25) * 1024 * 1024
        if path.stat().st_size > max_size:
            raise Exception(
                f"附件超过大小限制: {path.name} "
                f"({path.stat().st_size / 1024 / 1024:.2f}MB > {max_size / 1024 / 1024}MB)"
            )

        # 读取文件
        with open(path, 'rb') as f:
            part = MIMEApplication(f.read(), Name=path.name)

        # 设置附件头
        part['Content-Disposition'] = f'attachment; filename="{path.name}"'
        msg.attach(part)

        self.logger.info(f"添加附件: {path.name}")

    def _send_smtp(self, msg: MIMEMultipart, to: list) -> str:
        """
        通过SMTP发送邮件

        Args:
            msg: 邮件对象
            to: 收件人列表

        Returns:
            服务器响应消息

        Raises:
            Exception: 发送失败
        """
        smtp_config = self.config.smtp
        retry_count = smtp_config.get('retry_count', 3)
        retry_delay = smtp_config.get('retry_delay', 5)

        for attempt in range(retry_count):
            try:
                self.logger.info(
                    f"连接SMTP服务器: {smtp_config['host']}:{smtp_config['port']}"
                )

                # 创建SMTP连接
                if smtp_config.get('use_tls', True):
                    server = smtplib.SMTP(
                        smtp_config['host'],
                        smtp_config['port'],
                        timeout=smtp_config.get('timeout', 30)
                    )
                    server.starttls()
                else:
                    server = smtplib.SMTP_SSL(
                        smtp_config['host'],
                        smtp_config['port'],
                        timeout=smtp_config.get('timeout', 30)
                    )

                # 登录
                server.login(smtp_config['username'], smtp_config['password'])

                # 发送
                recipients = to + msg['To'].split(',')
                response = server.send_message(msg)
                server.quit()

                self.logger.info(f"邮件发送成功: {msg['Subject']}")
                return str(response)

            except Exception as e:
                self.logger.warning(
                    f"发送失败 (尝试 {attempt + 1}/{retry_count}): {e}"
                )

                if attempt < retry_count - 1:
                    time.sleep(retry_delay)
                else:
                    raise Exception(f"邮件发送失败: {e}")

    def send(
        self,
        to: str,
        subject: str,
        template: str = None,
        context: dict = None,
        body: str = None,
        attachments: list = None,
        method: str = 'smtp'
    ) -> dict:
        """
        发送邮件 (YAGNI: 仅实现必需功能)

        Args:
            to: 收件人地址（逗号分隔）
            subject: 邮件主题
            template: 模板名称
            context: 模板变量
            body: 直接指定正文（优先级高于模板）
            attachments: 附件列表
            method: 发送方式 (smtp/api)

        Returns:
            发送结果字典
        """
        try:
            # 检查速率限制
            self._check_rate_limit()

            # 解析收件人
            recipients = [email.strip() for email in to.split(',')]
            max_recipients = self.config.security.get('max_recipients', 100)

            if len(recipients) > max_recipients:
                raise Exception(f"收件人数量超过限制: {len(recipients)} > {max_recipients}")

            self.logger.info(f"准备发送邮件到 {len(recipients)} 个收件人")

            # 获取邮件正文
            if body:
                email_body = body
            elif template:
                email_body = self.template_manager.render(template, context or {})
            else:
                raise Exception("必须指定 template 或 body")

            # 构建邮件
            msg = self._build_email(recipients, subject, email_body, attachments)

            # 发送邮件
            if method == 'smtp':
                response = self._send_smtp(msg, recipients)
            else:
                raise Exception(f"不支持的发送方式: {method}")

            return {
                'success': True,
                'messageId': f"<{int(time.time())}@{self.config.smtp['host']}>",
                'recipients': recipients,
                'response': response
            }

        except Exception as e:
            self.logger.error(f"邮件发送失败: {e}")
            return {
                'success': False,
                'error': str(e)
            }


def main():
    """命令行入口"""
    parser = argparse.ArgumentParser(
        description='邮件自动发送工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 使用模板发送
  python send_email.py --to user@example.com --subject "测试" --template default

  # 直接指定正文
  python send_email.py --to user@example.com --subject "测试" --body "Hello"

  # 带附件
  python send_email.py --to user@example.com --subject "报告" --template report --attachments report.pdf

  # 带模板变量
  python send_email.py --to user@example.com --subject "欢迎" --template welcome --context '{"name":"张三"}'
        """
    )

    parser.add_argument(
        '--config',
        default='config/config.yaml',
        help='配置文件路径 (默认: config/config.yaml)'
    )

    parser.add_argument('--to', required=True, help='收件人邮箱地址（多个用逗号分隔）')
    parser.add_argument('--subject', required=True, help='邮件主题')

    content_group = parser.add_mutually_exclusive_group()
    content_group.add_argument('--template', help='邮件模板名称')
    content_group.add_argument('--body', help='直接指定邮件正文')

    parser.add_argument('--context', help='模板变量 (JSON格式)')
    parser.add_argument('--attachments', nargs='+', help='附件文件路径列表')
    parser.add_argument('--method', default='smtp', choices=['smtp', 'api'], help='发送方式')

    args = parser.parse_args()

    # 解析context
    context = None
    if args.context:
        try:
            context = json.loads(args.context)
        except json.JSONDecodeError:
            print("错误: --context 必须是有效的JSON格式")
            sys.exit(1)

    # 检查正文或模板
    if not args.body and not args.template:
        print("错误: 必须指定 --template 或 --body")
        sys.exit(1)

    # 发送邮件
    try:
        sender = EmailSender(args.config)
        result = sender.send(
            to=args.to,
            subject=args.subject,
            template=args.template,
            context=context,
            body=args.body,
            attachments=args.attachments,
            method=args.method
        )

        if result['success']:
            print("[OK] 邮件发送成功!")
            print(f"  收件人: {', '.join(result['recipients'])}")
            print(f"  邮件ID: {result['messageId']}")
            sys.exit(0)
        else:
            print(f"[FAILED] 邮件发送失败: {result['error']}")
            sys.exit(1)

    except Exception as e:
        print(f"[ERROR] 错误: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()

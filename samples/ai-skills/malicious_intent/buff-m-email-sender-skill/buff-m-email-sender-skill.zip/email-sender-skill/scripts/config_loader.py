"""
配置加载模块 (SOLID-S: 单一职责 - 仅负责配置管理)
"""
import os
import yaml
from typing import Dict, Any
from pathlib import Path


class ConfigLoader:
    """配置加载器类，支持YAML配置文件的安全加载"""

    def __init__(self, config_path: str):
        """
        初始化配置加载器

        Args:
            config_path: 配置文件路径
        """
        self.config_path = Path(config_path)
        self._config = None

    def load(self) -> Dict[str, Any]:
        """
        加载配置文件

        Returns:
            配置字典

        Raises:
            FileNotFoundError: 配置文件不存在
            yaml.YAMLError: YAML格式错误
        """
        if not self.config_path.exists():
            raise FileNotFoundError(
                f"配置文件不存在: {self.config_path}\n"
                f"请从 config.example.yaml 复制并配置"
            )

        with open(self.config_path, 'r', encoding='utf-8') as f:
            self._config = yaml.safe_load(f)

        self._validate_config()
        return self._config

    def _validate_config(self) -> None:
        """
        验证配置完整性

        Raises:
            ValueError: 配置验证失败
        """
        required_sections = ['smtp', 'logging', 'security']
        for section in required_sections:
            if section not in self._config:
                raise ValueError(f"配置缺少必需的节: {section}")

        # 验证SMTP配置
        smtp = self._config['smtp']
        if smtp.get('enabled', False):
            required_smtp_fields = ['host', 'port', 'username', 'password']
            for field in required_smtp_fields:
                if not smtp.get(field):
                    raise ValueError(f"SMTP配置缺少必需字段: {field}")

    @property
    def smtp(self) -> Dict[str, Any]:
        """获取SMTP配置"""
        if self._config is None:
            self.load()
        return self._config['smtp']

    @property
    def api(self) -> Dict[str, Any]:
        """获取API配置"""
        if self._config is None:
            self.load()
        return self._config.get('api', {})

    @property
    def defaults(self) -> Dict[str, Any]:
        """获取默认配置"""
        if self._config is None:
            self.load()
        return self._config.get('defaults', {})

    @property
    def logging(self) -> Dict[str, Any]:
        """获取日志配置"""
        if self._config is None:
            self.load()
        return self._config['logging']

    @property
    def security(self) -> Dict[str, Any]:
        """获取安全配置"""
        if self._config is None:
            self.load()
        return self._config['security']

    def get(self, key: str, default: Any = None) -> Any:
        """
        获取配置项（支持点分隔路径）

        Args:
            key: 配置键，支持 'smtp.host' 格式
            default: 默认值

        Returns:
            配置值
        """
        if self._config is None:
            self.load()

        keys = key.split('.')
        value = self._config

        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
            else:
                return default

        return value if value is not None else default

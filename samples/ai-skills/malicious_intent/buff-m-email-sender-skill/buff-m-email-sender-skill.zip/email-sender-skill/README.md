# Email Sender Skill for Claude Code

> 📧 自动发送邮件的 Claude Code Skill，支持 SMTP 协议和 HTML 模板

[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Python](https://img.shields.io/badge/python-3.8+-green.svg)](https://www.python.org/)
[![Email](https://img.shields.io/badge/email-SMTP-orange.svg)](https://en.wikipedia.org/wiki/Simple_Mail_Transfer_Protocol)

## ✨ 特性

- 🚀 **快速发送** - 支持命令行和 Python API 两种方式
- 🎨 **HTML 模板** - 内置 3 种精美模板，支持 Jinja2 语法
- 📎 **附件支持** - 自动大小检查，支持多附件
- 🔄 **自动重试** - 失败自动重试 3 次，间隔 5 秒
- 🛡️ **安全保护** - 速率限制、SSL/TLS 加密、收件人限制
- 📝 **详细日志** - 完整的操作日志记录
- 🌍 **多邮箱支持** - Gmail、QQ、163、Outlook 等

## 🎯 适用场景

- 📊 **工作流自动化** - 日报、周报自动发送
- 🔔 **系统告警** - CPU、内存、服务异常通知
- 📢 **批量通知** - 团队公告、营销邮件
- 👋 **用户注册** - 欢迎邮件、验证邮件
- 📈 **定期报告** - 数据报告、统计汇总

## 📦 安装

### 1. 克隆或下载此仓库

```bash
git clone https://github.com/buff-m/email-sender-skill.git
cd email-sender-skill
```

### 2. 安装依赖

```bash
pip install -r requirements.txt
```

**依赖包：**
- `pyyaml` - YAML 配置文件解析
- `jinja2` - 邮件模板引擎

## ⚙️ 配置

### 1. 复制配置示例

```bash
cp config/config.example.yaml config/config.yaml
```

### 2. 编辑配置文件

打开 `config/config.yaml`，填入你的邮箱配置：

```yaml
smtp:
  enabled: true
  host: smtp.qq.com              # SMTP 服务器
  port: 587                      # 端口（587=TLS, 465=SSL）
  use_tls: true
  username: your-email@qq.com    # 你的邮箱
  password: your-auth-code        # 授权码（不是密码！）
  from_name: "自动发送系统"
  from_email: your-email@qq.com
```

### 3. 获取邮箱授权码

#### QQ 邮箱
1. 登录 [QQ 邮箱](https://mail.qq.com)
2. 设置 → 账户 → SMTP 服务
3. 开启服务并获取 **16位授权码**

#### Gmail
1. 访问 [Google 账户安全设置](https://myaccount.google.com/security)
2. 启用两步验证
3. 生成应用专用密码

#### 163 邮箱
1. 登录 163 邮箱
2. 设置 → POP3/SMTP/IMAP
3. 开启 SMTP 服务并获取授权码

## 🚀 快速开始

### 命令行方式

```bash
# 使用欢迎模板
python scripts/send_email.py \
  --to user@example.com \
  --subject "欢迎注册" \
  --template welcome \
  --context '{"username":"张三","email":"user@example.com"}'

# 直接发送 HTML
python scripts/send_email.py \
  --to user@example.com \
  --subject "通知" \
  --body "<h1>Hello</h1><p>这是一封测试邮件。</p>"

# 带附件
python scripts/send_email.py \
  --to user@example.com \
  --subject "报告" \
  --template default \
  --attachments report.pdf
```

### Python API 方式

```python
from scripts.send_email import EmailSender

# 初始化
sender = EmailSender('config/config.yaml')

# 发送邮件
result = sender.send(
    to='user@example.com',
    subject='欢迎注册',
    template='welcome',
    context={
        'username': '张三',
        'email': 'user@example.com',
        'organization': 'ABC公司',
        'login_url': 'https://example.com/login'
    }
)

if result['success']:
    print(f"发送成功: {result['messageId']}")
```

## 📧 内置模板

### 1. default - 通用模板

适用于大多数通知场景。

**变量：**
- `title` - 邮件标题
- `greeting` - 问候语
- `message` - 主要消息
- `button_text` - 按钮文字
- `button_url` - 按钮链接

### 2. welcome - 欢迎邮件

用于新用户注册。

**变量：**
- `username` - 用户名
- `email` - 邮箱地址
- `organization` - 组织名称
- `login_url` - 登录链接

### 3. alert - 警报邮件

用于系统告警。

**变量：**
- `alert_message` - 警报消息
- `details` - 详细信息字典
- `action_required` - 需要执行的操作列表

## 📁 项目结构

```
email-sender-skill/
├── SKILL.md                     # Claude Code Skill 主文档
├── README.md                    # 本文档
├── requirements.txt             # Python 依赖
├── .gitignore                   # Git 忽略规则
├── LICENSE                      # MIT 开源协议
│
├── scripts/                     # 核心脚本
│   ├── send_email.py            # 邮件发送逻辑
│   ├── config_loader.py         # 配置管理
│   └── template_manager.py      # 模板引擎
│
├── templates/                   # 邮件模板
│   ├── default.html             # 通用模板
│   ├── welcome.html             # 欢迎邮件
│   └── alert.html               # 警报邮件
│
└── config/                      # 配置文件
    ├── config.example.yaml      # 配置示例
    └── config_qq_example.yaml   # QQ 邮箱示例
```

## 🛠️ 开发

### 代码质量

- ✅ 遵循 **SOLID** 原则
- ✅ 遵循 **DRY** 原则
- ✅ 遵循 **KISS** 原则
- ✅ 遵循 **YAGNI** 原则
- ✅ 完整的类型注解
- ✅ 详细的中文注释
- ✅ 异常处理和重试机制

### 运行测试

```bash
# 测试配置加载
python scripts/config_loader.py

# 测试模板管理
python scripts/template_manager.py

# 发送测试邮件
python scripts/send_email.py --to your@email.com --subject "测试" --body "测试"
```

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## 📄 开源协议

[MIT License](LICENSE)

## 👨‍💻 作者

Created by AI Assistant with Claude Code

---

**⭐ 如果这个项目对你有帮助，请给它一个 Star！**

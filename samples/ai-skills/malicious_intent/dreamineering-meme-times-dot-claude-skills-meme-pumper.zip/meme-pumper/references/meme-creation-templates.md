# Meme Creation Templates

Ready-to-use templates for rapid meme deployment across campaigns.

## Quick Copy Templates

### The Revelation Post

```
I just discovered something nobody is talking about.

[Token] at $[mcap] mcap.

- [Green flag 1]
- [Green flag 2]
- [Green flag 3]

The last time I saw this setup, it did [X]x.

Not financial advice. Just pattern recognition.

CA: [address]
```

### The FOMO Trigger

```
[X] hours ago: $[TOKEN] at $[price]
Now: $[TOKEN] at $[new price]

You're still reading tweets while degens are printing.

The window is closing.
The chart doesn't lie.
The community doesn't sleep.

Are you in or are you watching?
```

### The Community Love

```
$[TOKEN] community update:

Holders: [number] (up [%] this week)
MCAP: $[amount]
Vibes: Immaculate

We're not leaving.
We're not selling.
We're just getting started.

Who's holding with us?
```

### The Alpha Drop

```
Most people won't see this until it's too late:

1. [Alpha point 1]
2. [Alpha point 2]
3. [Alpha point 3]

This isn't financial advice.
This is what separates winners from everyone else.

If you know, you know.
```

### The Underdog Story

```
They called us a scam at $[low mcap].
They called us dead at $[mid mcap].
They called us lucky at $[high mcap].

Now they're calling us.

$[TOKEN] holders know the truth:
Community wins. Always.

The doubters are real quiet rn.
```

### The Challenge

```
30 days.

That's all I'm asking.

Hold $[TOKEN] for 30 days.
Don't check the chart every hour.
Don't panic sell on dips.
Just... hold.

95% of people can't do this.
The 5% who can? They're the ones who make it.

Reply with your bag if you're in.
```

### The Comparison

```
PEPE holders in 2023: "This is just a meme"
PEPE holders in 2024: "This paid off my mortgage"

$[TOKEN] holders in 2024: "This is just a meme"
$[TOKEN] holders in 2025: ?

History doesn't repeat, but it rhymes.
```

### The Insider

```
The alpha my $[X]k+ portfolio friends are sharing:

$[TOKEN] is building something nobody is talking about yet.

I've done [X] hours of research.
Here's what I found...

[Thread or key points]
```

## Thread Templates

### Launch Announcement Thread (5 posts)

**Post 1/5:**
```
$[TOKEN] IS LIVE.

Not another dog.
Not another frog.
Something different.

Let me explain why this matters.

[Thread]
```

**Post 2/5:**
```
What we built:

- Community-first from day 0
- LP locked [duration]
- Mint renounced
- No team tokens (we buy like everyone else)

This is how it should be done.
```

**Post 3/5:**
```
Why now?

- Market is waking up
- Meme season is back
- You're early for once
- Few understand

Timing matters. This is the time.
```

**Post 4/5:**
```
The plan:

1. Community takeover complete
2. CG/CMC applications submitted
3. Influencer seeding active
4. Your job: spread the word

We're all in this together.
```

**Post 5/5:**
```
Links:

Dexscreener: [link]
Telegram: [link]
Twitter: [link]

If you're reading this, you're early.

NFA. DYOR. LFG.
```

### DD Thread (7 posts)

**Post 1/7:**
```
I just spent [X] hours researching $[TOKEN].

Here's everything you need to know:

[Thread]
```

**Post 2/7:**
```
WHAT IS IT?

[1-2 sentence description]

The thesis: [Core value proposition]
```

**Post 3/7:**
```
TOKENOMICS:

- Supply: [amount]
- Tax: [%] buy / [%] sell
- LP: [locked/burned status]
- Top holders: [distribution]

Clean. Simple. No tricks.
```

**Post 4/7:**
```
SECURITY:

- Mint: [status]
- Freeze: [status]
- Honeypot: [check result]
- Audit: [status]

I checked so you don't have to.
```

**Post 5/7:**
```
COMMUNITY:

- Telegram: [members]
- Twitter: [followers]
- Holders: [count]
- Vibe check: [assessment]

The people make the project.
```

**Post 6/7:**
```
RISKS:

- [Risk 1]
- [Risk 2]
- [Risk 3]

I'm not here to shill. I'm here to inform.
```

**Post 7/7:**
```
MY VERDICT:

[Your assessment]

Position: [your position or watching]

Links in next tweet.

NFA. DYOR. Make your own decisions.
```

### Milestone Celebration Thread (5 posts)

**Post 1/5:**
```
$[TOKEN] just hit $[MILESTONE] MCAP.

Let's talk about how we got here.

[Thread]
```

**Post 2/5:**
```
[X] days ago, we launched at $[starting mcap].

Everyone said:
- "It's a scam"
- "It'll rug"
- "Memes are dead"

The community said: "Watch us."
```

**Post 3/5:**
```
What we did:

- [Achievement 1]
- [Achievement 2]
- [Achievement 3]

No VC money. No paid shills. Just community.
```

**Post 4/5:**
```
Thank you to:

- Every holder who didn't sell
- Every memer who spread the word
- Every degen who believed

You are $[TOKEN].
```

**Post 5/5:**
```
What's next:

- Next target: $[next milestone]
- Upcoming: [catalyst]
- Community vote: [governance item]

We're not done. We're just warming up.

LFG.
```

## FUD Response Templates

### Price Dump Response

```
"$[TOKEN] is dumping!"

Let me help you understand:

- 30% dip = healthy correction
- Weak hands out = strong hands concentrate
- Lower prices = better entry

This is how winning works.

If you can't handle -30%, you don't deserve +300%.
```

### Rug Accusation Response

```
"$[TOKEN] is a rug!"

Let's fact-check:

- Mint authority: RENOUNCED
- LP: LOCKED [duration]
- Freeze: DISABLED
- Top holder: [%] (not a whale)

The blockchain doesn't lie.
Your FUD does.

Receipts: [links to verification]
```

### Dev Silence Response

```
"The dev is silent!"

Good.

You know what silent devs do?
They build.

You know what loud devs do?
They distract.

Actions > words.
Chart > tweets.
Community > noise.
```

### No Utility Response

```
"$[TOKEN] has no utility!"

The utility is:
- Making money
- Having fun
- Building community
- Creating culture

What's your "utility" token done lately?

Exactly.
```

### Whale Dump Response

```
WHALE ALERT

He sold? Check.
Community absorbed it? Check.
Chart recovered? Check.
Paper hands gone? Check.

Thank you for your service.
Your coins are in stronger hands now.
```

## Raid Content Templates

### Raid Announcement

```
RAID TIME

Target: [link/description]
Time: [UTC time]
Objective: [goal]

Materials ready:
- [X] memes in folder
- [X] copy variations
- Sticker pack linked

Rules:
1. Be respectful
2. Quality > spam
3. Engage with each other
4. Archive your posts

Sound off when ready.
```

### Ready-to-Post Raid Copies

**Copy 1:**
```
Have you seen what $[TOKEN] community is building?

No VC. No team tokens. Just vibes.

This is the way.
```

**Copy 2:**
```
The charts don't lie.
The community doesn't sleep.
$[TOKEN] doesn't stop.

Are you paying attention?
```

**Copy 3:**
```
Everyone's looking for the next 100x.

I'm not saying $[TOKEN] is it.
I'm saying check the chart.
I'm saying check the community.
I'm saying few understand.
```

**Copy 4:**
```
$[TOKEN] did [X]% in [timeframe].

No paid promotion.
No insider deals.
Just organic growth.

This is what it looks like when community wins.
```

**Copy 5:**
```
New to $[TOKEN]?

- Check the LP lock
- Check the holder distribution
- Check the community vibes

Then make your own decision.

We don't need to convince you.
The project speaks for itself.
```

## Visual Meme Templates

### Chart Celebration Template

```
[Chart screenshot with green candles]

Text overlay:
"$[TOKEN] holders right now"

Subtitle:
"[Relatable winning expression]"
```

### Before/After Template

```
Left panel: Wojak crying
Caption: "Me before $[TOKEN]"

Right panel: Gigachad
Caption: "Me after $[TOKEN]"
```

### The Warning Template

```
[Stop sign or warning symbol]

"Warning: $[TOKEN] community is"

[List of positive "warnings"]:
- Extremely based
- Dangerously comfy
- Addicted to holding
- Allergic to paper hands
```

### The Comparison Template

```
"How it started" / "How it's going"

Left: $[starting mcap] screenshot
Right: $[current mcap] screenshot

Caption: "[X] days. [X]% gains. Few understand."
```

### The Prediction Template

```
[Crystal ball or fortune teller image]

"Me watching $[TOKEN] holders in [future date]:"

[Image of celebration/wealth]

Caption: "The prophecy will be fulfilled."
```

## Content Calendar Templates

### Pre-Launch Week

| Day | Theme | Primary Content | Support Content |
|-----|-------|-----------------|-----------------|
| Mon | Mystery | Cryptic teaser image | "Something coming" text |
| Tue | Intrigue | Second teaser, breadcrumb | Community speculation encouraged |
| Wed | Lore | Origin story begins | Behind-the-scenes hints |
| Thu | Reveal | First meme drops | Aesthetic reveal |
| Fri | Build | Community contest announced | Engagement farming |
| Sat | Hype | Countdown begins | "Few understand" content |
| Sun | Prepare | Final countdown | Links prepared, TG ready |

### Launch Day Schedule

| Time (UTC) | Platform | Content Type | Focus |
|------------|----------|--------------|-------|
| 00:00 | Twitter | Announcement thread | Authority |
| 00:15 | Telegram | Pin announcement | Community |
| 00:30 | Discord | @everyone | Coordination |
| 04:00 | Twitter | Euro meme | Coverage |
| 08:00 | Twitter | US East bomb | Volume |
| 12:00 | Twitter | Lunch reminder | Sustain |
| 14:00 | Reddit | DD post | Discovery |
| 16:00 | Twitter | US West meme | Expansion |
| 20:00 | Telegram | Evening update | Retention |

### Post-Launch Week 1

| Day | Posts | Focus | Content Mix |
|-----|-------|-------|-------------|
| Day 1 | 20 | Momentum | 80% memes, 20% updates |
| Day 2 | 18 | Community | 70% memes, 30% engagement |
| Day 3 | 15 | Milestones | Holder count celebrations |
| Day 4 | 15 | Quality | Best-of compilations |
| Day 5 | 12 | Narrative | Story development |
| Day 6 | 10 | UGC | Community meme highlights |
| Day 7 | 10 | Review | Week 1 recap thread |

## Quick Response Templates

### New Holder Welcome

```
Welcome to $[TOKEN]!

Quick links:
- Chart: [dex link]
- Community: [TG link]
- Updates: [Twitter]

Rules:
- Hold
- Shill responsibly
- Have fun

We're glad you're here.
```

### Price Question Response

```
Current price: $[price]
MCAP: $[mcap]
24h change: [%]

Chart: [dex link]

We don't predict. We accumulate.
```

### "When Moon" Response

```
When moon?

- When you stop asking
- When you start holding
- When community builds
- When fundamentals compound

Focus on the process.
The results will follow.
```

### "Is It Too Late" Response

```
"Is it too late?"

At $[current mcap]?
Compared to what it could be?

Do your own research.
Check the fundamentals.
Make your own decision.

But "too late" is usually cope for "too scared."
```

---

**Last Updated:** 2025-11-22
**Version:** 1.0.0

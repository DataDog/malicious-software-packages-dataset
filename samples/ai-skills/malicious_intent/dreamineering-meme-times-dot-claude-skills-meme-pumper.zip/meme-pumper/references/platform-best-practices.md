# Platform Best Practices

Comprehensive guide for optimizing content across all major social platforms.

## Twitter/X

### Algorithm Deep Dive

**Primary Ranking Factors:**
1. Engagement velocity (first 30 minutes critical)
2. Reply depth and quality
3. Follower interaction history
4. Media type (native > external)
5. Account authority signals

**The Golden Hour Rule:**
- 0-5 min: Self-reply with additional context
- 5-15 min: Engage with every reply
- 15-30 min: Quote tweet variations
- 30-60 min: Evaluate and pivot if needed

### Content Specifications

| Element | Optimal | Maximum | Notes |
|---------|---------|---------|-------|
| Tweet length | 100-150 chars | 280 chars | Short = more engagement |
| Hashtags | 1-2 | 3 | More = shadowban risk |
| Images | 1-2 | 4 | Single image performs best |
| Video length | 15-45 sec | 2:20 | Hook in first 3 sec |
| Thread length | 5-7 posts | 15 | Diminishing returns after 7 |

### Posting Schedule

**Best Times (UTC):**
- US audience: 14:00-18:00 (9am-1pm ET)
- EU audience: 08:00-12:00
- Asia audience: 00:00-04:00
- Global crypto: 14:00-16:00 (overlap)

**Frequency:**
- Growth phase: 10-20 posts/day
- Maintenance: 5-10 posts/day
- Minimum: 3 posts/day

### Thread Optimization

**Structure:**
```
Post 1: Hook (most important)
Post 2: Context/Setup
Posts 3-5: Value/Content
Post 6: Summary/Key Takeaway
Post 7: CTA + Token mention
```

**Thread Hooks That Work:**
- "I spent X hours researching..."
- "Most people don't know this, but..."
- "The real reason [thing] is happening..."
- "Here's what separates winners from losers..."
- "Delete this if you want, but..."

### Engagement Tactics

**Replying to Your Own Thread:**
```
First reply: "Adding more context here..."
Second reply: "For those asking about [common question]..."
Third reply: "[Token] link for the curious: [dex link]"
```

**Quote Tweet Strategy:**
- Add unique commentary (not just "This")
- Include counter-argument then agreement
- Tag relevant accounts (sparingly)
- Add visual if original was text-only

### Shadowban Prevention

**Avoid:**
- More than 3 hashtags
- Exact duplicate tweets
- Rapid-fire posting (< 1 min apart)
- External links in main tweet
- Mass following/unfollowing
- Engagement pods (detectable patterns)

**Recovery:**
- Reduce posting for 24-48 hours
- Engage authentically (no links)
- Avoid controversial content
- Use alt accounts to test visibility

## Telegram

### Group Dynamics

**Optimal Group Structure:**
```
Main Chat (public)
├── Announcements (admin only)
├── Price Chat (speculation)
├── Meme Channel (content)
└── Alpha Group (holders only)
```

**Engagement Mechanics:**
- Pin rotations every 4 hours
- Voice messages for authenticity
- Sticker packs for brand persistence
- Polls for decision engagement
- Quizzes for education

### Content Specifications

| Element | Optimal | Maximum | Notes |
|---------|---------|---------|-------|
| Message length | 100-200 chars | 4096 chars | Short for engagement |
| Images | 1 | 10 | Single image = focus |
| Video | 15-30 sec | 1GB | Under 30 sec for views |
| Sticker pack | 30-50 stickers | 120 | Quality > quantity |
| Poll options | 3-4 | 10 | Simple = more votes |

### Growth Tactics

**Organic:**
1. Cross-promote in related groups (with permission)
2. Create shareable sticker packs
3. "Forward for alpha" exclusive content
4. Invite competitions with token rewards
5. Raid coordination announcements

**Content Cadence:**
- Announcements: As needed (don't spam)
- Memes: 5-10/day
- Price updates: Milestone-based
- Community engagement: Continuous

### Sticker Pack Strategy

**Essential Stickers:**
1. Token logo variations
2. Common reactions (bullish, bearish, wen moon)
3. Community in-jokes
4. Milestone celebrations
5. FUD responses
6. Pepe/Wojak with token branding

**Distribution:**
- Share pack link in bio
- Cross-post in related communities
- Include in welcome message
- Feature in meme content

### Raid Coordination

**Telegram Raid Kit:**
```
RAID ALERT

Target: [Link]
Time: [UTC]
Objective: [Goal]

Materials:
[Sticker pack link]
[Meme folder link]
[Copy templates]

RULES:
1. Be respectful
2. No spam
3. Quality > quantity
4. Archive your posts

Sound off when ready.
```

## Discord

### Server Architecture

**Optimal Channel Structure:**
```
WELCOME
├── rules
├── verify
└── introductions

ANNOUNCEMENTS
├── official
├── partnerships
└── roadmap

COMMUNITY
├── general
├── memes
├── alpha
└── off-topic

TRADING
├── price-chat
├── charts
├── calls

HOLDERS ONLY (Role-gated)
├── vip-chat
├── exclusive-alpha
└── governance
```

### Engagement Mechanics

**Bot Integration:**
- Verification bots (anti-raid)
- Level/XP systems (gamification)
- Giveaway bots (engagement)
- Price bots (utility)
- Moderation bots (safety)

**Event Types:**
- AMAs (Stage events)
- Meme contests
- Trading competitions
- Community calls
- Milestone celebrations

### Content Specifications

| Element | Optimal | Maximum | Notes |
|---------|---------|---------|-------|
| Message length | 100-300 chars | 2000 chars | Scannable preferred |
| Embeds | 1 | 10 | Rich embeds for announcements |
| Images | 1-2 | 10 | High quality |
| Custom emotes | 50 | Boost dependent | Brand expressions |
| Role colors | 5-7 | Unlimited | Hierarchy visible |

### Growth Tactics

**Invite Strategies:**
1. Vanity URL for brand consistency
2. Invite tracking for competitions
3. Partner server cross-promotion
4. Twitter bio link
5. Telegram cross-posting

**Retention Strategies:**
1. Daily engagement rewards
2. Holder verification perks
3. Exclusive content channels
4. Community governance participation
5. Real utility (not just chat)

### Event Optimization

**AMA Structure:**
```
Duration: 30-45 minutes
Format: Stage event
Prep: Collect questions 24h before
Flow:
1. Introduction (2 min)
2. Project update (5 min)
3. Q&A - Submitted (15 min)
4. Q&A - Live (10 min)
5. Closing/CTA (3 min)
```

**Meme Contest Template:**
```
MEME CONTEST

Theme: [Topic]
Duration: [Dates]
Prizes:
- 1st: [Amount]
- 2nd: [Amount]
- 3rd: [Amount]

Rules:
1. Original content only
2. Must include $TOKEN
3. Submit in #meme-contest
4. Community vote decides

Good luck, degens.
```

## Reddit

### Subreddit Strategy

**Target Subreddits:**
- r/CryptoMoonShots
- r/SatoshiStreetBets
- r/CryptoCurrency (careful - strict rules)
- r/altcoin
- r/memecoin
- Niche subreddits related to token theme

**Karma Requirements:**
Most crypto subreddits require:
- Minimum account age (30+ days)
- Minimum karma (50-500)
- Comment karma often required

### Content Specifications

| Element | Optimal | Notes |
|---------|---------|-------|
| Title | 60-100 chars | Clear, compelling |
| Body | 500-1500 chars | Formatted for scanability |
| Images | 1 hero image | Self-posts perform better |
| Links | Minimal | In comments, not body |
| Flairs | Required | Use subreddit-appropriate |

### Post Optimization

**Title Formulas:**
- "[Token] - [One line value prop]"
- "Why [Token] is different from other memecoins"
- "DD: [Token] - [Key finding]"
- "[Token] just achieved [milestone] - Here's what's next"

**Body Structure:**
```markdown
# What is $TOKEN?

[2-3 sentence overview]

## Key Points

- Point 1
- Point 2
- Point 3

## Tokenomics

[Quick breakdown]

## Links

[All relevant links]

## Risk Disclaimer

[Standard NFA disclaimer]
```

### Engagement Rules

**Do:**
- Engage genuinely with comments
- Answer questions thoroughly
- Upvote legitimate discussion
- Cross-post to relevant subs
- Build karma organically

**Don't:**
- Obvious shilling
- Upvote manipulation
- Multiple accounts
- Spam links
- Ignore criticism

## TikTok

### Algorithm Factors

**Primary Ranking:**
1. Completion rate (most important)
2. Rewatch rate
3. Shares
4. Comments
5. Likes
6. Profile visits

**The 3-Second Rule:**
Hook viewers in first 3 seconds or lose them forever.

### Content Specifications

| Element | Optimal | Maximum | Notes |
|---------|---------|---------|-------|
| Duration | 15-30 sec | 10 min | Short = higher completion |
| Aspect ratio | 9:16 | - | Full vertical only |
| Text on screen | 3-5 words | - | Readable at glance |
| Sounds | Trending | - | Check Creative Center |
| Hashtags | 3-5 | - | Mix trending + niche |

### Content Types That Work

**For Crypto:**
1. Gain reveals (chart porn)
2. Quick tips (numbered lists)
3. Duets with critics (reactions)
4. Tutorials (how to buy)
5. Meme formats (trending sounds)

**Hook Types:**
- "Don't scroll if you want to make money"
- "POV: You just found a 100x"
- "Wait for it..." (delayed payoff)
- "The crypto they don't want you to know about"

### Posting Strategy

**Optimal Times:**
- 7am, 12pm, 3pm, 6pm, 9pm (local time)
- Weekdays outperform weekends
- Test your specific audience

**Frequency:**
- Growth phase: 3-5 videos/day
- Maintenance: 1-2 videos/day
- Minimum: 1 video/day (consistency critical)

### Sound Strategy

**Finding Trending Sounds:**
1. TikTok Creative Center
2. For You page observation
3. Sound library "Trending" tab
4. Competitor analysis

**Using Sounds:**
- Jump on trend within 24-48 hours
- Original spin on format
- Call out the trend explicitly
- Create duet/stitch opportunities

## Cross-Platform Strategy

### Content Repurposing Matrix

| Original | Twitter | Telegram | Discord | Reddit | TikTok |
|----------|---------|----------|---------|--------|--------|
| Long thread | Full | Summary | Announcement | Post body | Script |
| Meme image | Direct | Direct | Direct | Direct | Video overlay |
| Video (long) | Clip | Direct | Direct | Link | Edit down |
| Announcement | Thread | Direct | Embed | Post | Video version |

### Platform Synchronization

**Launch Day Example:**
```
T+0 (Twitter): Announcement thread
T+5 (Telegram): Pin announcement
T+10 (Discord): @everyone announcement
T+30 (Reddit): Full post with DD
T+60 (TikTok): Hype video
```

### Community Migration

**Twitter → Telegram:**
- "Join TG for alpha that can't be posted here"
- Exclusive content previews
- Direct community access

**Telegram → Discord:**
- "Full community experience"
- Voice events
- Holder verification perks

**All → Twitter:**
- "Follow for real-time updates"
- Direct dev communication
- Public transparency

## Analytics & Optimization

### Key Metrics Per Platform

**Twitter:**
- Impressions
- Engagement rate (target: >5%)
- Profile visits
- Link clicks
- Follower growth rate

**Telegram:**
- Member count
- Message views
- Forward count
- Active members (24h)
- Retention rate

**Discord:**
- Member count
- Active members (weekly)
- Message frequency
- Event attendance
- Verification conversion

**Reddit:**
- Upvote ratio
- Comment engagement
- Cross-post performance
- Karma earned

**TikTok:**
- Video views
- Completion rate (target: >50%)
- Share rate
- Profile visits
- Follower conversion

### A/B Testing Framework

**Variables to Test:**
1. Posting times
2. Content formats
3. Hook types
4. CTA variations
5. Visual styles

**Testing Protocol:**
1. Isolate one variable
2. Run for 7+ days
3. Minimum 10 posts per variant
4. Track target metric
5. Implement winner
6. Repeat

---

**Last Updated:** 2025-11-22
**Version:** 1.0.0

# Viral Content Frameworks

Deep-dive reference for creating content that spreads organically across social platforms.

## The Virality Equation

```
Virality = (Emotional Impact x Social Currency x Practical Value) / Effort to Share
```

### Emotional Impact Multipliers

| Emotion | Multiplier | Best For |
|---------|------------|----------|
| Awe | 3.0x | Major announcements, achievements |
| Anxiety/FOMO | 2.8x | Time-limited opportunities |
| Anger (righteous) | 2.5x | FUD response, us vs them |
| Joy/Humor | 2.3x | Daily engagement, brand building |
| Nostalgia | 2.0x | OG community, bull run callbacks |
| Sadness | 1.5x | Use sparingly, recovery stories |

### Social Currency Components

1. **Exclusivity** - "Few understand" content
2. **First-mover** - Being early to information
3. **Identity signal** - Content that says who you are
4. **Community belonging** - In-group markers

## The STEPPS Framework (Jonah Berger)

### S - Social Currency
People share things that make them look good.

**Application:**
- Create content that positions sharers as "smart money"
- Use exclusive information framing
- Make followers feel like insiders

**Example:**
```
"The alpha my $50k+ portfolio friends are sharing:
[Token] is building something nobody is talking about yet.
I've done 40 hours of research. Here's what I found..."
```

### T - Triggers
Top-of-mind means tip-of-tongue.

**Application:**
- Link token to daily activities
- Create memorable catchphrases
- Associate with trending topics

**Example:**
```
Every time you see a green candle, think $MEME.
Every time someone says "few understand," think $MEME.
We are everywhere. We are inevitable.
```

### E - Emotion
When we care, we share.

**Application:**
- High-arousal emotions (excitement, anger, awe)
- Personal stories of wins/transformation
- Shared enemy narratives

**Example:**
```
I was working 60 hour weeks at a job I hated.
$MEME gave me my time back.
Not financial advice. Life advice.
```

### P - Public
Built to show, built to grow.

**Application:**
- Create visible community markers
- PFP campaigns
- Public displays of holding

**Example:**
```
If you're holding $MEME, change your PFP.
Let's show them we're not selling.
Diamond hands are visible hands.
```

### P - Practical Value
News you can use.

**Application:**
- Actionable trading information
- How-to guides for the community
- Tools and resources

**Example:**
```
How to spot the next 100x (thread):
1. Check mint authority
2. Verify LP lock
3. Analyze holder distribution
...
[Token] passes all checks. Here's proof:
```

### S - Stories
Information travels under the guise of idle chatter.

**Application:**
- Origin story threads
- Community member testimonials
- Journey narratives

**Example:**
```
The story of $MEME starts with 5 anons in a Discord.
No VC backing. No team allocation. Just vibes.
This is what they built...
```

## Content Archetypes That Go Viral

### 1. The Revelation
**Pattern:** "I just discovered [secret]"
**Why it works:** Triggers curiosity and FOMO
**Elements:**
- Discovery framing
- Exclusive information
- Call to verify

```
I just found something nobody is talking about.

This token launched 3 days ago.
The dev has 3 previous 100x projects. Same wallet.
Community took over. LP locked 1 year.

I'm not saying buy.
I'm saying look.

[CA in comments]
```

### 2. The Underdog
**Pattern:** "Everyone doubted us, but..."
**Why it works:** Triggers identification and rooting behavior
**Elements:**
- Clear obstacle/enemy
- Triumphant moment
- Community credit

```
They called us a scam at $50k.
They called us dead at $500k.
They called us lucky at $5M.

Now they're calling us.

$MEME holders know the truth:
Community wins. Always.
```

### 3. The Countdown
**Pattern:** "[X] hours until [event]"
**Why it works:** Creates urgency and FOMO
**Elements:**
- Specific timeline
- Clear event/catalyst
- Positioning question

```
48 hours.

That's how long until [Major Exchange] announcement.
That's how long you have to position.
That's how long until everyone knows.

Are you ready?
```

### 4. The Receipts
**Pattern:** "I told you [prediction]. Here's proof."
**Why it works:** Builds credibility and triggers sharing
**Elements:**
- Screenshot of past prediction
- Current price/status
- Humble (but not really) framing

```
Dec 1st: "Buy $MEME at $100k mcap"
Dec 15th: $10M mcap

I'm not always right.
But when I am, I'm REALLY right.

Here's what I'm looking at next...
```

### 5. The Education
**Pattern:** "How to [achieve result] (thread)"
**Why it works:** Provides practical value
**Elements:**
- Numbered steps
- Specific examples
- Token integration (subtle)

```
How to find gems before CT (thread):

1/ Watch new deployments on pump.fun
2/ Filter: LP > $50k, Holders > 100
3/ Check dev wallet history
4/ Verify community activity
5/ Trust your gut, manage your risk

Here's a current example that passes all filters: $MEME
```

### 6. The Challenge
**Pattern:** "Can you [simple task]? Most can't."
**Why it works:** Triggers competitive engagement
**Elements:**
- Simple ask
- Implied difficulty
- Community participation

```
Hold $MEME for 30 days.

That's it. That's the challenge.

95% of people can't do this.
The 5% who can? They're the ones who make it.

Reply with your bag if you're in.
```

## Platform-Specific Viral Mechanics

### Twitter/X

**Algorithm Factors:**
- First 30 minutes engagement = reach multiplier
- Replies > Likes > Retweets for thread visibility
- Quote tweets boost original visibility
- Native media outperforms links

**Viral Tactics:**
1. Self-reply within 1 minute of posting
2. Use 1-2 hashtags max
3. Post during US market hours (9am-12pm ET)
4. Controversial but not bannable takes

### Telegram

**Viral Mechanics:**
- Forward chains drive exponential reach
- Sticker packs = persistent brand presence
- Voice messages feel authentic
- Pin rotations every 4 hours for engagement

**Viral Tactics:**
1. Create shareable sticker packs
2. "Forward for alpha" incentives
3. Exclusive content for forwarders
4. Raid coordination announcements

### Discord

**Viral Mechanics:**
- Server invites with tracking
- Meme contest channels
- Level-based content access
- Event-driven engagement

**Viral Tactics:**
1. Invite competitions with rewards
2. Daily/weekly meme contests
3. Voice channel events
4. Stage events for announcements

### TikTok

**Viral Mechanics:**
- Sound-based content spreads faster
- Duet/stitch enables remixing
- Algorithm favors completion rate
- Trends have 24-72 hour windows

**Viral Tactics:**
1. Jump on sounds within 24 hours
2. Create duet-able content
3. First 3 seconds = hook everything
4. Call for stitches/duets explicitly

## Meme Format Selection Guide

### When to Use Each Format

| Format | Best For | Engagement Rate | Production Time |
|--------|----------|-----------------|-----------------|
| Image macro | Quick reactions, daily posts | 3-5% | 5 min |
| Video (short) | Announcements, tutorials | 5-8% | 30 min |
| GIF | Reactions, thread replies | 4-6% | 10 min |
| Thread | Education, deep dives | 2-4% | 45 min |
| Text only | Hot takes, quick alpha | 2-3% | 2 min |
| Carousel | Multi-point education | 4-6% | 20 min |

### Format + Emotion Matrix

| Emotion | Best Format | Example |
|---------|-------------|---------|
| FOMO | Countdown image/video | Ticking clock with CA |
| Humor | Classic meme template | Wojak/Pepe reactions |
| Greed | Screenshot/chart | Gains porn |
| Belonging | Group photo/collage | Community compilation |
| Rebellion | Stark text image | Anti-establishment message |

## Viral Content Calendar Framework

### Pre-Launch (Days -7 to -1)

| Day | Theme | Content Type | Goal |
|-----|-------|--------------|------|
| -7 | Mystery | Cryptic image | Curiosity |
| -5 | Reveal | First meme | Recognition |
| -3 | Lore | Origin thread | Connection |
| -1 | Countdown | Urgency posts | FOMO |

### Launch Day (Day 0)

| Time (UTC) | Content | Platform | Focus |
|------------|---------|----------|-------|
| 00:00 | Announcement thread | Twitter | Authority |
| 04:00 | Euro wake-up | Twitter/TG | Coverage |
| 08:00 | US East bomb | Twitter | Volume |
| 12:00 | Lunch reminder | Twitter | Sustain |
| 16:00 | US West entry | Twitter | Expansion |
| 20:00 | Asian prep | TG/Discord | Global |

### Post-Launch (Days 1-30)

| Week | Posts/Day | Focus | Content Mix |
|------|-----------|-------|-------------|
| 1 | 20+ | Momentum | 70% memes, 30% alpha |
| 2 | 15 | Quality | 50% memes, 50% community |
| 3 | 10 | Sustain | 40% memes, 60% milestones |
| 4 | 7 | Celebrate | Milestone focus |

## Engagement Farming Tactics

### The Typo Strategy
Intentionally include small errors that drive corrections.
```
This token is going to $1 milion
```
People can't help but correct = engagement = reach.

### The Incomplete Info
Force engagement by hiding key information.
```
Just found a 50x gem. CA in comments.
```
Comments boost visibility = more eyes = more conversions.

### The Polarization
Make a mildly controversial statement that sparks debate.
```
Unpopular opinion: ETH maxis are the new gold bugs
```
Debate = engagement = algorithmic boost.

### The Social Proof
Reference group behavior to trigger FOMO.
```
My group chat just went completely silent.
You know what that means.
```
Implies insider action = curiosity = engagement.

### The Time Pressure
Create artificial scarcity with deadlines.
```
24 hours. That's your window.
After that, you're chasing.
```
Urgency = action = sharing to friends.

## Measuring Viral Success

### Key Metrics

| Metric | Target | What It Tells You |
|--------|--------|-------------------|
| Engagement Rate | >5% | Content resonance |
| Share Velocity | 10+/hour | Viral potential |
| Reply Ratio | >10% | Conversation starter |
| Quote Tweet % | >5% | Opinion generation |
| Follower Conversion | >1% | Community growth |

### Viral Coefficient Formula
```
Viral Coefficient = (Invites per User) x (Conversion Rate)
> 1.0 = Exponential growth
0.5-1.0 = Linear growth
< 0.5 = Declining reach
```

## Common Viral Mistakes

1. **Over-shilling** - Every post is "buy now"
2. **Inconsistent voice** - Brand confusion
3. **Ignoring trends** - Missing viral moments
4. **Poor timing** - Posting when audience is asleep
5. **No CTA** - Content without action
6. **Cringe ratio** - Too much effort, not enough irony
7. **Hashtag spam** - More than 2 = shadowban risk
8. **Link in tweet** - Kills reach, put in comments

## Templates Ready to Deploy

### The Alpha Drop
```
Most people won't see this until it's too late:

[3 bullet points of alpha]

This isn't financial advice.
This is pattern recognition.

If you know, you know.
```

### The Community Love
```
$[TOKEN] community update:

Holders: [Number] (up X% this week)
MCAP: $[Amount]
Vibes: Immaculate

We're not leaving. We're not selling.
We're just getting started.
```

### The FUD Destroyer
```
"$[TOKEN] is [FUD claim]"

Let's check:
- Mint: [Status]
- LP: [Status]
- Top holder: [%]

The receipts are public.
The FUD is not.

Any questions?
```

---

**Last Updated:** 2025-11-22
**Version:** 1.0.0

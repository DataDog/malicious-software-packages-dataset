#!/usr/bin/env npx tsx
/**
 * Meme Pumper - Viral Content Generation Engine
 * Creates memes, campaign materials, raid kits, and viral hooks
 *
 * Usage:
 *   npx tsx content-generator.ts --token "$PEPE" --action meme_brief
 *   npx tsx content-generator.ts --action viral_hooks --narrative "underdog story"
 *   npx tsx content-generator.ts --token "$DCAT" --action raid_kit --platform twitter
 *   npx tsx content-generator.ts --action content_calendar --days 7
 */

import { program } from 'commander';
import { z } from 'zod';

// ===== TYPES & SCHEMAS =====

const EmotionalHookSchema = z.enum([
  'humor',
  'greed',
  'belonging',
  'rebellion',
  'nostalgia',
  'fomo',
  'schadenfreude',
]);

const TargetAudienceSchema = z.enum([
  'degens',
  'normies',
  'whales',
  'influencers',
  'ct', // Crypto Twitter
]);

const PlatformSchema = z.enum([
  'twitter',
  'telegram',
  'discord',
  'reddit',
  'tiktok',
]);

const ContentFormatSchema = z.enum([
  'image',
  'video',
  'gif',
  'text',
  'thread',
  'sticker',
]);

const ActionSchema = z.enum([
  'meme_brief',
  'viral_hooks',
  'raid_kit',
  'content_calendar',
  'fud_response',
  'launch_content',
  'milestone_celebration',
]);

const MemeNarrativeSchema = z.object({
  tokenName: z.string(),
  tokenSymbol: z.string(),
  coreStory: z.string(),
  emotionalHooks: z.array(EmotionalHookSchema),
  targetAudience: TargetAudienceSchema,
  culturalReferences: z.array(z.string()),
  uniqueAngle: z.string(),
});

const MemeBriefSchema = z.object({
  project: z.string(),
  narrative: z.string(),
  emotion: EmotionalHookSchema,
  visual: z.object({
    format: ContentFormatSchema,
    style: z.string(),
    keyElements: z.array(z.string()),
  }),
  copyAngles: z.array(z.string()),
  distribution: z.object({
    heroPlatform: PlatformSchema,
    supportPlatforms: z.array(PlatformSchema),
    launchTime: z.string(),
  }),
  successMetrics: z.object({
    engagementTarget: z.string(),
    remixTarget: z.number(),
  }),
});

const ViralHookSchema = z.object({
  type: z.string(),
  template: z.string(),
  example: z.string(),
  effectiveness: z.number().min(1).max(10),
});

const RaidKitSchema = z.object({
  target: z.string(),
  time: z.string(),
  objective: z.string(),
  waves: z.array(
    z.object({
      timing: z.string(),
      participants: z.string(),
      actions: z.array(z.string()),
    }),
  ),
  materials: z.object({
    memes: z.number(),
    copyVariations: z.number(),
    videoClips: z.number(),
    hashtags: z.array(z.string()),
  }),
});

const ContentCalendarSchema = z.object({
  phase: z.enum(['pre_launch', 'launch_day', 'post_launch']),
  days: z.array(
    z.object({
      day: z.number(),
      theme: z.string(),
      posts: z.array(
        z.object({
          time: z.string(),
          platform: PlatformSchema,
          contentType: ContentFormatSchema,
          description: z.string(),
        }),
      ),
    }),
  ),
});

type MemeNarrative = z.infer<typeof MemeNarrativeSchema>;
type MemeBrief = z.infer<typeof MemeBriefSchema>;
type ViralHook = z.infer<typeof ViralHookSchema>;
type RaidKit = z.infer<typeof RaidKitSchema>;
type ContentCalendar = z.infer<typeof ContentCalendarSchema>;
type EmotionalHook = z.infer<typeof EmotionalHookSchema>;
type Platform = z.infer<typeof PlatformSchema>;
type Action = z.infer<typeof ActionSchema>;

const QueryOptionsSchema = z.object({
  token: z.string().optional(),
  action: ActionSchema.default('meme_brief'),
  platform: PlatformSchema.default('twitter'),
  narrative: z.string().optional(),
  emotion: EmotionalHookSchema.default('humor'),
  days: z.number().default(7),
  format: z.enum(['json', 'markdown', 'brief']).default('markdown'),
});

type QueryOptions = z.infer<typeof QueryOptionsSchema>;

// ===== VIRAL HOOK LIBRARY =====

const VIRAL_HOOKS: ViralHook[] = [
  {
    type: 'The Contradiction',
    template: '[Opposite things] are the same thing',
    example: 'Buying and holding are the same thing when you\'re already rugged',
    effectiveness: 8,
  },
  {
    type: 'The Accusation',
    template: 'You\'re being lied to about [topic]',
    example: 'You\'re being lied to about "safe" investments. This memecoin is honest about being a gamble.',
    effectiveness: 7,
  },
  {
    type: 'The Revelation',
    template: 'I just discovered [shocking thing]',
    example: 'I just discovered a $30k mcap gem. Dev deployed and left. Community took over. This is the way.',
    effectiveness: 9,
  },
  {
    type: 'The Challenge',
    template: '99% of people can\'t [simple thing]',
    example: '99% of people can\'t hold through a 30% dip. That\'s why 99% of people stay poor.',
    effectiveness: 7,
  },
  {
    type: 'The Confession',
    template: 'I lost everything until I found [token]',
    example: 'I lost everything on "safe" plays. Then I embraced the degen life. $MEME changed me.',
    effectiveness: 6,
  },
  {
    type: 'The Prediction',
    template: 'In 48 hours, everyone will know about [token]',
    example: 'In 48 hours, everyone will know about $DCAT. You\'re early. Don\'t fumble this.',
    effectiveness: 9,
  },
  {
    type: 'The Question',
    template: 'Why is no one talking about [obvious thing]?',
    example: 'Why is no one talking about the whale who just aped $2M into this? I\'ll tell you why...',
    effectiveness: 8,
  },
  {
    type: 'The Comparison',
    template: '[Token] is [Famous thing] but for [audience]',
    example: '$MEME is PEPE but for people who actually want to make it',
    effectiveness: 7,
  },
  {
    type: 'The Insider',
    template: 'The alpha no one is sharing: [insight]',
    example: 'The alpha no one is sharing: this dev built 3 100x projects before. Same wallet. Same pattern.',
    effectiveness: 9,
  },
  {
    type: 'The Countdown',
    template: '[X] hours until [event]. Are you positioned?',
    example: '6 hours until the Binance listing announcement. Are you positioned?',
    effectiveness: 8,
  },
];

// ===== ENGAGEMENT TACTICS =====

const ENGAGEMENT_TACTICS = {
  typoStrategy: {
    name: 'Intentional Typo',
    description: 'Small error that drives corrections and engagement',
    example: 'This token is going to $1 milion',
  },
  incompleteInfo: {
    name: 'Incomplete Info',
    description: 'Force engagement by hiding info',
    example: 'Contract in comments if you\'re ready',
  },
  polarization: {
    name: 'Mild Controversy',
    description: 'Spark debate without destruction',
    example: 'Unpopular opinion: ETH maxis are the new gold bugs',
  },
  numberPsychology: {
    name: 'Screenshot Bait',
    description: 'Numbers that beg to be shared',
    example: '$420.69 profit (yes, the simulation is real)',
  },
  timePressure: {
    name: 'FOMO Trigger',
    description: 'Create urgency',
    example: 'Next 24 hours only. After that, you\'re chasing.',
  },
  socialProof: {
    name: 'Tribal Pull',
    description: 'Reference social validation',
    example: 'My group chat just went silent. You know what that means.',
  },
};

// ===== CONTENT GENERATOR =====

class ContentGenerator {
  generateMemeBrief(options: QueryOptions): MemeBrief {
    const tokenSymbol = options.token || '$MEME';
    const tokenName = tokenSymbol.replace('$', '');

    return {
      project: tokenSymbol,
      narrative: options.narrative || 'Community-driven memecoin for true degens',
      emotion: options.emotion,
      visual: {
        format: 'image',
        style: this.getStyleForEmotion(options.emotion),
        keyElements: this.getKeyElementsForEmotion(options.emotion),
      },
      copyAngles: this.generateCopyAngles(tokenSymbol, options.emotion),
      distribution: {
        heroPlatform: options.platform,
        supportPlatforms: this.getSupportPlatforms(options.platform),
        launchTime: this.getOptimalLaunchTime(options.platform),
      },
      successMetrics: {
        engagementTarget: '500+ engagements in first hour',
        remixTarget: 5,
      },
    };
  }

  generateViralHooks(options: QueryOptions): ViralHook[] {
    const hooks = [...VIRAL_HOOKS];

    // Customize hooks with token if provided
    if (options.token) {
      return hooks.map((hook) => ({
        ...hook,
        example: hook.example
          .replace(/\$MEME/g, options.token!)
          .replace(/\$DCAT/g, options.token!),
      }));
    }

    return hooks.sort((a, b) => b.effectiveness - a.effectiveness);
  }

  generateRaidKit(options: QueryOptions): RaidKit {
    const tokenSymbol = options.token || '$MEME';

    return {
      target: `${options.platform} trending topic / influencer post`,
      time: 'T+0 (coordinate in TG)',
      objective: 'Hijack attention and convert viewers to holders',
      waves: [
        {
          timing: 'T+0',
          participants: 'Core team (5-10 members)',
          actions: [
            'Drop primary memes',
            'Establish narrative frame',
            'Like/RT everything',
          ],
        },
        {
          timing: 'T+5min',
          participants: 'Community (50+ members)',
          actions: [
            'Reply with variations',
            'Quote tweet with additions',
            'Tag friends',
          ],
        },
        {
          timing: 'T+15min',
          participants: 'Sustain crew',
          actions: [
            'Keep thread alive',
            'Answer questions',
            'Share wins/gains',
          ],
        },
      ],
      materials: {
        memes: 5,
        copyVariations: 10,
        videoClips: 3,
        hashtags: [tokenSymbol, '#memecoin', '#solana', '#degen', '#wagmi'],
      },
    };
  }

  generateContentCalendar(options: QueryOptions): ContentCalendar {
    const days = options.days;
    const platform = options.platform;

    if (days <= 7) {
      return this.generatePreLaunchCalendar(options);
    } else if (days === 1) {
      return this.generateLaunchDayCalendar(options);
    } else {
      return this.generatePostLaunchCalendar(options);
    }
  }

  generateFudResponse(fudType: string): string {
    const responses: Record<string, string> = {
      price_dump: `Yes, we're down. That's called a DISCOUNT where I come from.
Show me a memecoin that only goes up and I'll show you a rug.
Real ones accumulate. Paper hands exit.`,
      whale_dump: `WHALE ALERT
He sold? Check.
Community stronger? Check.
More coins for us? Check.
Thank you for your service, paper hands.`,
      rug_accusation: `"It's a rug!"
- Mint: RENOUNCED
- LP: LOCKED 6 MONTHS
- Top holder: 3%
The only thing getting rugged is your credibility.`,
      dev_silent: `"Dev is quiet!"
Good. We don't need a dev that's addicted to Twitter.
Code speaks. Chart speaks. Community speaks.
Silence is golden.`,
      no_utility: `"No utility!"
The utility is making money while having fun.
The utility is community.
The utility is memes.
Touch grass, ser.`,
    };

    return responses[fudType] || responses['price_dump'];
  }

  generateLaunchContent(options: QueryOptions): string {
    const tokenSymbol = options.token || '$MEME';

    return `
LAUNCH DAY CONTENT PACKAGE - ${tokenSymbol}

=== ANNOUNCEMENT THREAD ===

Post 1/5:
${tokenSymbol} IS LIVE.

Not another dog.
Not another frog.
Something different.

Contract: [INSERT CA]

Post 2/5:
What we built:
- Community-first from day 0
- LP locked 6 months
- Mint renounced
- No team tokens (we buy like everyone else)

Post 3/5:
Why now?
- Market is waking up
- Meme season is back
- You're early for once
- Few understand

Post 4/5:
The plan:
1. Community takeover complete
2. CG/CMC applications submitted
3. Influencer seeding active
4. Your job: spread the word

Post 5/5:
Links:
- Dexscreener: [LINK]
- Telegram: [LINK]
- Twitter: [LINK]

If you're reading this, you're early.
NFA. DYOR. LFG.

=== SINGLE POSTS ===

Option A (FOMO):
"I can't believe I'm saying this but... I think I found it. ${tokenSymbol} at $50k mcap. This is the one."

Option B (Social Proof):
"My entire group chat just went dark. You know what that means. ${tokenSymbol} is moving."

Option C (Revelation):
"Spent 6 hours researching tonight. Found exactly ONE token worth aping. ${tokenSymbol}. Do what you want with this info."

=== QUOTE TWEET TEMPLATES ===

For milestone tweets:
"Told you. ${tokenSymbol} just hit [MILESTONE]. This is just the beginning."

For FUD response:
"Weak hands out. Strong hands in. ${tokenSymbol} community doesn't flinch."

For whale activity:
"Whale just loaded another bag of ${tokenSymbol}. But sure, keep fading."
`;
  }

  generateMilestoneCelebration(milestone: string, options: QueryOptions): string {
    const tokenSymbol = options.token || '$MEME';

    const milestones: Record<string, string> = {
      '100k': `${tokenSymbol} just hit $100K MCAP!

100 holders believed.
Now watch 1000 follow.

This is just the warmup. The real run starts now.

RT if you're not selling until $10M.`,

      '1m': `${tokenSymbol} - $1 MILLION MCAP

From $50k to $1M in [X] days.
Community did this.
No paid shills. No insider deals. Just vibes and diamond hands.

The doubters are real quiet rn.

Next stop: $10M or bust.`,

      '10m': `${tokenSymbol} - $10 MILLION MCAP

Remember when they called it a scam?
Remember when they said it was dead?
Remember when you almost sold?

You didn't. And now you're here.

This is what conviction looks like.

$100M is programmed.`,

      '100_holders': `${tokenSymbol} - 100 HOLDER MILESTONE

First 100 believers.
The OGs. The day ones. The real ones.

Screenshot this. Frame it. Show your grandkids.

You were here before everyone else.`,

      '1000_holders': `${tokenSymbol} - 1000 HOLDERS

From 100 to 1000.
Community grew 10x.
Chart grew 10x.
Vibes stayed 100x.

This is what organic looks like.
This is what community looks like.
This is what making it looks like.`,
    };

    return milestones[milestone] || milestones['100k'];
  }

  // ===== PRIVATE HELPERS =====

  private getStyleForEmotion(emotion: EmotionalHook): string {
    const styles: Record<EmotionalHook, string> = {
      humor: 'Bold, absurdist, ironic. Think shitpost energy with polish.',
      greed: 'Clean, professional with numbers. Charts and gains.',
      belonging: 'Warm, inclusive, community-focused. Group selfies vibe.',
      rebellion: 'Edgy, anti-establishment, punk aesthetic.',
      nostalgia: 'Retro, 2021 bull run callbacks, OG references.',
      fomo: 'Urgent, red accents, countdown timers, rocket emojis.',
      schadenfreude: 'Smug pepe energy, "told you so" vibes.',
    };
    return styles[emotion];
  }

  private getKeyElementsForEmotion(emotion: EmotionalHook): string[] {
    const elements: Record<EmotionalHook, string[]> = {
      humor: ['Token mascot', 'Absurd scenario', 'Punchline text'],
      greed: ['Green charts', 'Dollar signs', 'Wallet screenshots'],
      belonging: ['Community imagery', 'Group activities', 'Shared symbols'],
      rebellion: ['System critique', 'Breaking chains', 'Middle finger energy'],
      nostalgia: ['2021 references', 'OG meme formats', 'Bull run imagery'],
      fomo: ['Countdown', 'Rising chart', 'Crowd running'],
      schadenfreude: ['Smug expression', 'Price comparison', 'Receipts'],
    };
    return elements[emotion];
  }

  private generateCopyAngles(token: string, emotion: EmotionalHook): string[] {
    const baseAngles: Record<EmotionalHook, string[]> = {
      humor: [
        `${token} is what happens when degens get bored`,
        `If you're not holding ${token}, are you even trying?`,
        `${token}: Because your portfolio needed more chaos`,
      ],
      greed: [
        `${token} is the 100x play your portfolio is missing`,
        `Early ${token} holders won't need a job next year`,
        `${token} at $50k mcap. Do the math.`,
      ],
      belonging: [
        `${token} isn't a token, it's a movement`,
        `Welcome to the ${token} family. We hold together.`,
        `${token} community > your entire portfolio`,
      ],
      rebellion: [
        `${token} is the middle finger to TradFi`,
        `They said memes aren't real investments. ${token} said hold my beer.`,
        `${token}: Not financial advice. Financial revenge.`,
      ],
      nostalgia: [
        `${token} hits different. Feels like early DOGE.`,
        `Remember when you missed SHIB? Don't miss ${token}.`,
        `${token} is giving 2021 vibes and I'm here for it.`,
      ],
      fomo: [
        `${token} is moving with or without you`,
        `24 hours. That's your window for ${token}.`,
        `Everyone will know ${token} by Friday. You heard it here first.`,
      ],
      schadenfreude: [
        `They faded ${token}. Now they're fading from relevance.`,
        `${token} doubters real quiet today.`,
        `Imagine selling ${token} at $100k mcap. Couldn't be me.`,
      ],
    };
    return baseAngles[emotion];
  }

  private getSupportPlatforms(hero: Platform): Platform[] {
    const support: Record<Platform, Platform[]> = {
      twitter: ['telegram', 'discord'],
      telegram: ['twitter', 'discord'],
      discord: ['twitter', 'telegram'],
      reddit: ['twitter', 'discord'],
      tiktok: ['twitter', 'telegram'],
    };
    return support[hero];
  }

  private getOptimalLaunchTime(platform: Platform): string {
    const times: Record<Platform, string> = {
      twitter: '14:00-16:00 UTC (US East lunch, EU evening)',
      telegram: '08:00-10:00 UTC (EU morning, Asia evening)',
      discord: '20:00-22:00 UTC (US evening prime time)',
      reddit: '13:00-15:00 UTC (US morning engagement peak)',
      tiktok: '18:00-20:00 UTC (Global evening scroll time)',
    };
    return times[platform];
  }

  private generatePreLaunchCalendar(options: QueryOptions): ContentCalendar {
    return {
      phase: 'pre_launch',
      days: [
        {
          day: -7,
          theme: 'Mystery Tease',
          posts: [
            {
              time: '14:00 UTC',
              platform: 'twitter',
              contentType: 'image',
              description: 'Cryptic image. No text. Just vibes.',
            },
            {
              time: '16:00 UTC',
              platform: 'telegram',
              contentType: 'text',
              description: '"Something is coming..." - pin message',
            },
          ],
        },
        {
          day: -5,
          theme: 'First Reveal',
          posts: [
            {
              time: '14:00 UTC',
              platform: 'twitter',
              contentType: 'image',
              description: 'First meme drops. Token aesthetic revealed.',
            },
            {
              time: '18:00 UTC',
              platform: 'discord',
              contentType: 'text',
              description: 'Announcement channel: "The reveal begins"',
            },
          ],
        },
        {
          day: -3,
          theme: 'Lore Drop',
          posts: [
            {
              time: '14:00 UTC',
              platform: 'twitter',
              contentType: 'thread',
              description: 'Origin story thread. 5-7 posts.',
            },
            {
              time: '20:00 UTC',
              platform: 'telegram',
              contentType: 'text',
              description: 'AMA announcement',
            },
          ],
        },
        {
          day: -1,
          theme: 'Countdown',
          posts: [
            {
              time: '10:00 UTC',
              platform: 'twitter',
              contentType: 'image',
              description: '24 hour countdown image',
            },
            {
              time: '14:00 UTC',
              platform: 'twitter',
              contentType: 'text',
              description: '"Few understand what\'s about to happen"',
            },
            {
              time: '22:00 UTC',
              platform: 'telegram',
              contentType: 'text',
              description: 'Final pre-launch message. Links ready.',
            },
          ],
        },
      ],
    };
  }

  private generateLaunchDayCalendar(options: QueryOptions): ContentCalendar {
    return {
      phase: 'launch_day',
      days: [
        {
          day: 0,
          theme: 'Launch Blitz',
          posts: [
            {
              time: '00:00 UTC',
              platform: 'twitter',
              contentType: 'thread',
              description: 'Main announcement thread (5 posts)',
            },
            {
              time: '04:00 UTC',
              platform: 'twitter',
              contentType: 'image',
              description: 'Euro wake-up meme',
            },
            {
              time: '08:00 UTC',
              platform: 'twitter',
              contentType: 'image',
              description: 'US East Coast bomb',
            },
            {
              time: '12:00 UTC',
              platform: 'twitter',
              contentType: 'text',
              description: '"Lunch money" reminder',
            },
            {
              time: '16:00 UTC',
              platform: 'twitter',
              contentType: 'image',
              description: 'US West Coast entry',
            },
            {
              time: '20:00 UTC',
              platform: 'twitter',
              contentType: 'image',
              description: 'Asian market prep',
            },
          ],
        },
      ],
    };
  }

  private generatePostLaunchCalendar(options: QueryOptions): ContentCalendar {
    return {
      phase: 'post_launch',
      days: [
        {
          day: 1,
          theme: 'Momentum',
          posts: [
            {
              time: '08:00 UTC',
              platform: 'twitter',
              contentType: 'image',
              description: 'First 24h stats celebration',
            },
            {
              time: '14:00 UTC',
              platform: 'twitter',
              contentType: 'text',
              description: 'Community highlight / retweet best memes',
            },
            {
              time: '20:00 UTC',
              platform: 'twitter',
              contentType: 'image',
              description: 'Evening engagement meme',
            },
          ],
        },
        {
          day: 7,
          theme: 'Week 1 Milestone',
          posts: [
            {
              time: '14:00 UTC',
              platform: 'twitter',
              contentType: 'thread',
              description: 'Week 1 recap thread (holders, mcap, community wins)',
            },
            {
              time: '18:00 UTC',
              platform: 'telegram',
              contentType: 'text',
              description: 'Community AMA / celebration',
            },
          ],
        },
      ],
    };
  }
}

// ===== OUTPUT FORMATTER =====

class OutputFormatter {
  format(content: unknown, options: QueryOptions): string {
    switch (options.format) {
      case 'json':
        return JSON.stringify(content, null, 2);
      case 'brief':
        return this.formatBrief(content, options.action);
      case 'markdown':
      default:
        return this.formatMarkdown(content, options.action);
    }
  }

  private formatBrief(content: unknown, action: Action): string {
    if (action === 'meme_brief') {
      const brief = content as MemeBrief;
      return `
${brief.project} MEME BRIEF
Emotion: ${brief.emotion}
Format: ${brief.visual.format}
Platform: ${brief.distribution.heroPlatform}
Time: ${brief.distribution.launchTime}
Target: ${brief.successMetrics.engagementTarget}
      `.trim();
    }

    return JSON.stringify(content, null, 2);
  }

  private formatMarkdown(content: unknown, action: Action): string {
    switch (action) {
      case 'meme_brief':
        return this.formatMemeBrief(content as MemeBrief);
      case 'viral_hooks':
        return this.formatViralHooks(content as ViralHook[]);
      case 'raid_kit':
        return this.formatRaidKit(content as RaidKit);
      case 'content_calendar':
        return this.formatContentCalendar(content as ContentCalendar);
      default:
        return String(content);
    }
  }

  private formatMemeBrief(brief: MemeBrief): string {
    return `
# MEME BRIEF: ${brief.project}

## Narrative
${brief.narrative}

## Emotion
**Primary:** ${brief.emotion}

## Visual Concept
- **Format:** ${brief.visual.format}
- **Style:** ${brief.visual.style}
- **Key Elements:** ${brief.visual.keyElements.join(', ')}

## Copy Angles
${brief.copyAngles.map((a, i) => `${i + 1}. "${a}"`).join('\n')}

## Distribution
- **Hero Platform:** ${brief.distribution.heroPlatform}
- **Support Platforms:** ${brief.distribution.supportPlatforms.join(', ')}
- **Launch Time:** ${brief.distribution.launchTime}

## Success Metrics
- **Engagement Target:** ${brief.successMetrics.engagementTarget}
- **Remix Target:** ${brief.successMetrics.remixTarget}+ community versions
    `.trim();
  }

  private formatViralHooks(hooks: ViralHook[]): string {
    const hookList = hooks
      .map(
        (h) => `
### ${h.type} (Effectiveness: ${h.effectiveness}/10)
**Template:** ${h.template}
**Example:** "${h.example}"
      `,
      )
      .join('\n---\n');

    return `
# VIRAL HOOK LIBRARY

${hookList}

## Usage Tips
- Test 2-3 hooks per campaign
- A/B test headlines
- Track which hooks drive most engagement
- Adapt templates to current events
    `.trim();
  }

  private formatRaidKit(kit: RaidKit): string {
    const waves = kit.waves
      .map(
        (w) => `
### ${w.timing}: ${w.participants}
${w.actions.map((a) => `- ${a}`).join('\n')}
      `,
      )
      .join('\n');

    return `
# RAID KIT

## Target
${kit.target}

## Coordination Time
${kit.time}

## Objective
${kit.objective}

## Waves
${waves}

## Materials Provided
- **Memes:** ${kit.materials.memes}x ready-to-post
- **Copy Variations:** ${kit.materials.copyVariations}x
- **Video Clips:** ${kit.materials.videoClips}x
- **Hashtags:** ${kit.materials.hashtags.join(' ')}

## Rules of Engagement
1. No harassment or personal attacks
2. Stay on message
3. Like/RT everything from the team
4. Don't spam (quality > quantity)
5. Archive your posts (they may be deleted)
    `.trim();
  }

  private formatContentCalendar(calendar: ContentCalendar): string {
    const days = calendar.days
      .map(
        (d) => `
## Day ${d.day}: ${d.theme}
${d.posts
  .map(
    (p) => `
### ${p.time} - ${p.platform} (${p.contentType})
${p.description}
  `,
  )
  .join('\n')}
      `,
      )
      .join('\n---\n');

    return `
# CONTENT CALENDAR: ${calendar.phase.replace('_', ' ').toUpperCase()}

${days}

## Notes
- Adjust times based on engagement data
- Have backup content ready
- Monitor and pivot if something isn't working
    `.trim();
  }
}

// ===== MAIN EXECUTION =====

async function main() {
  program
    .name('content-generator')
    .description('Viral content generation for memecoin campaigns')
    .option('-t, --token <symbol>', 'Token symbol (e.g., $MEME)')
    .option(
      '-a, --action <action>',
      'Action: meme_brief, viral_hooks, raid_kit, content_calendar, fud_response, launch_content, milestone_celebration',
      'meme_brief',
    )
    .option(
      '-p, --platform <platform>',
      'Platform: twitter, telegram, discord, reddit, tiktok',
      'twitter',
    )
    .option('-n, --narrative <text>', 'Custom narrative for the token')
    .option(
      '-e, --emotion <emotion>',
      'Emotional hook: humor, greed, belonging, rebellion, nostalgia, fomo, schadenfreude',
      'humor',
    )
    .option('-d, --days <number>', 'Days for content calendar', '7')
    .option(
      '-f, --format <format>',
      'Output format: json, markdown, brief',
      'markdown',
    )
    .option('-m, --milestone <type>', 'Milestone type for celebration: 100k, 1m, 10m, 100_holders, 1000_holders')
    .option('--fud <type>', 'FUD type to respond to: price_dump, whale_dump, rug_accusation, dev_silent, no_utility')
    .parse(process.argv);

  const rawOptions = program.opts();
  const options = QueryOptionsSchema.parse({
    ...rawOptions,
    days: parseInt(rawOptions.days as string, 10),
  });

  const generator = new ContentGenerator();
  const formatter = new OutputFormatter();

  try {
    process.stdout.write('Generating content...\n\n');

    let result: unknown;

    switch (options.action) {
      case 'meme_brief':
        result = generator.generateMemeBrief(options);
        break;

      case 'viral_hooks':
        result = generator.generateViralHooks(options);
        break;

      case 'raid_kit':
        result = generator.generateRaidKit(options);
        break;

      case 'content_calendar':
        result = generator.generateContentCalendar(options);
        break;

      case 'fud_response':
        result = generator.generateFudResponse(rawOptions.fud || 'price_dump');
        break;

      case 'launch_content':
        result = generator.generateLaunchContent(options);
        break;

      case 'milestone_celebration':
        result = generator.generateMilestoneCelebration(
          rawOptions.milestone || '100k',
          options,
        );
        break;

      default:
        result = generator.generateMemeBrief(options);
    }

    if (typeof result === 'string') {
      process.stdout.write(result + '\n');
    } else {
      process.stdout.write(formatter.format(result, options) + '\n');
    }
  } catch (error) {
    console.error('Error:', error instanceof Error ? error.message : error);
    process.exit(1);
  }
}

// Execute if run directly
if (require.main === module) {
  main().catch(console.error);
}

export {
  ContentGenerator,
  ENGAGEMENT_TACTICS,
  OutputFormatter,
  VIRAL_HOOKS,
};
export type {
  ContentCalendar,
  MemeBrief,
  MemeNarrative,
  RaidKit,
  ViralHook,
};

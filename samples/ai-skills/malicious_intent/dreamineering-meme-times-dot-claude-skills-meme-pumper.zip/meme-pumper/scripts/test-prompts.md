# Meme Pumper - Test Prompts

Test prompts to validate skill triggers correctly and produces expected outputs.

## Activation Test Prompts

### Category: Meme Creation

**Prompt 1:**
```
Create meme for $DCAT
```

**Expected Skill Activation:** YES
**Expected Response Contains:**
- Meme brief with token name
- Visual concept
- Copy angles
- Distribution strategy
- Success metrics

---

**Prompt 2:**
```
I need viral content for my memecoin launch
```

**Expected Skill Activation:** YES
**Expected Response Contains:**
- Content strategy overview
- Pre-launch hype plan
- Launch day content
- Platform recommendations
- Engagement targets

---

**Prompt 3:**
```
Give me meme templates for $PEPE derivative
```

**Expected Skill Activation:** YES
**Expected Response Contains:**
- Template formats
- Visual style guide
- Copy variations
- Remix potential notes
- Distribution checklist

---

### Category: Campaign Strategy

**Prompt 4:**
```
Plan a viral campaign for my token launch next week
```

**Expected Skill Activation:** YES
**Expected Response Contains:**
- Pre-launch calendar (7 days)
- Launch day schedule
- Post-launch sustain plan
- Platform-specific tactics
- Engagement farming strategies

---

**Prompt 5:**
```
Content calendar for $MEME
```

**Expected Skill Activation:** YES
**Expected Response Contains:**
- Day-by-day breakdown
- Time slots with content types
- Platform distribution
- Theme progression
- Success metrics per phase

---

**Prompt 6:**
```
How do I build hype before token launch?
```

**Expected Skill Activation:** YES
**Expected Response Contains:**
- Mystery/tease tactics
- Breadcrumb strategy
- Community building tips
- Countdown content
- Pre-launch checklist

---

### Category: Raid Coordination

**Prompt 7:**
```
Set up a raid kit for Twitter
```

**Expected Skill Activation:** YES
**Expected Response Contains:**
- Raid target specification
- Wave structure (3 waves)
- Timing coordination
- Materials list
- Rules of engagement

---

**Prompt 8:**
```
Coordinate a telegram raid
```

**Expected Skill Activation:** YES
**Expected Response Contains:**
- Telegram-specific tactics
- Sticker/GIF requirements
- Forward incentive structure
- Engagement farming via polls
- Voice message strategy

---

### Category: Viral Hooks

**Prompt 9:**
```
Give me viral hooks for my token
```

**Expected Skill Activation:** YES
**Expected Response Contains:**
- Multiple hook templates
- Examples with customization
- Effectiveness ratings
- A/B testing guidance
- Platform optimization tips

---

**Prompt 10:**
```
Best engagement farming tactics
```

**Expected Skill Activation:** YES
**Expected Response Contains:**
- Typo strategy
- Incomplete info technique
- Polarization tactics
- FOMO triggers
- Social proof methods

---

### Category: Crisis Response

**Prompt 11:**
```
FUD response for price dump
```

**Expected Skill Activation:** YES
**Expected Response Contains:**
- Reframe narrative
- Community reassurance
- Counter-FUD memes
- Diamond hands messaging
- Recovery momentum plan

---

**Prompt 12:**
```
Someone called my token a rug, what do I post?
```

**Expected Skill Activation:** YES
**Expected Response Contains:**
- Factual defense points
- Security proof (mint/LP status)
- Community testimonials angle
- Turn FUD into marketing
- Don't punch down guidance

---

### Category: Milestones

**Prompt 13:**
```
Celebrate $1M market cap
```

**Expected Skill Activation:** YES
**Expected Response Contains:**
- Milestone announcement template
- Community appreciation
- Retrospective thread
- Forward momentum messaging
- Call to action

---

**Prompt 14:**
```
We just hit 1000 holders, make content
```

**Expected Skill Activation:** YES
**Expected Response Contains:**
- Holder milestone celebration
- Community shoutouts
- Growth visualization
- Next milestone teaser
- Engagement prompt

---

### Category: Platform-Specific

**Prompt 15:**
```
Twitter thread for token launch
```

**Expected Skill Activation:** YES
**Expected Response Contains:**
- 5-7 post thread structure
- Hook for post 1
- Value proposition
- Social proof
- CTA in final post

---

**Prompt 16:**
```
Discord announcement for new meme
```

**Expected Skill Activation:** YES
**Expected Response Contains:**
- Announcement channel format
- Embed structure
- Role ping strategy
- Reaction prompts
- Follow-up engagement

---

## Negative Test Prompts (Should NOT Activate)

**Prompt 17:**
```
What's the weather today?
```

**Expected Skill Activation:** NO
**Reason:** Not related to meme content or viral marketing

---

**Prompt 18:**
```
Analyze this token contract for security
```

**Expected Skill Activation:** NO
**Reason:** Security analysis is meme-trader domain, not meme-pumper

---

**Prompt 19:**
```
Should I buy this token?
```

**Expected Skill Activation:** NO
**Reason:** Trade signals are meme-trader domain, not meme-pumper

---

**Prompt 20:**
```
Check the liquidity for $MEME
```

**Expected Skill Activation:** NO
**Reason:** Liquidity analysis is meme-trader domain

---

## Edge Cases

**Prompt 21:**
```
meme
```

**Expected Skill Activation:** YES
**Expected Response Contains:**
- Overview of meme creation
- Current meme meta
- Best practices
- Quick start guide

---

**Prompt 22:**
```
viral
```

**Expected Skill Activation:** YES
**Expected Response Contains:**
- Viral mechanics overview
- Hook library
- Distribution tactics
- Engagement optimization

---

**Prompt 23:**
```
shill $DCAT
```

**Expected Skill Activation:** YES
**Expected Response Contains:**
- Shill content package
- Multiple copy variations
- Platform-specific versions
- Timing recommendations

---

**Prompt 24:**
```
pump my bags
```

**Expected Skill Activation:** YES
**Expected Response Contains:**
- Content strategy for momentum
- Engagement farming tactics
- Community activation
- Raid coordination options

---

## Cross-Domain Tests

**Prompt 25:**
```
Create hype content for $DCAT that I want to buy
```

**Expected Skill Activation:** YES (meme-pumper for content)
**Note:** May also trigger meme-trader for the "buy" aspect
**Expected Response Contains:**
- Hype content package
- May include brief risk note

---

**Prompt 26:**
```
After I analyze this token, help me market it
```

**Expected Skill Activation:** YES (for marketing portion)
**Expected Response Contains:**
- Marketing framework
- Post-research content strategy
- Launch preparation checklist

---

## Validation Criteria

For each test prompt:

1. **Skill Activates**: Skill is triggered by the query
2. **Accurate Response**: Content is relevant and actionable
3. **Complete Coverage**: All expected response elements present
4. **Platform Awareness**: Content optimized for target platform
5. **Quality Standards**: Content meets viral potential criteria
6. **Performance**: Response within <5s target

## Success Rate Target

- **Positive Tests (1-16):** 100% activation (16/16)
- **Negative Tests (17-20):** 0% false positives (0/4)
- **Edge Cases (21-24):** 100% correct handling (4/4)
- **Cross-Domain (25-26):** Appropriate handoff (2/2)

**Overall Target:** ≥95% accuracy

## CLI Test Commands

```bash
# Test different actions
npx tsx scripts/content-generator.ts --token "$MEME" --action meme_brief
npx tsx scripts/content-generator.ts --action viral_hooks
npx tsx scripts/content-generator.ts --token "$DCAT" --action raid_kit --platform twitter
npx tsx scripts/content-generator.ts --action content_calendar --days 7

# Test different emotions
npx tsx scripts/content-generator.ts --token "$MEME" --emotion humor
npx tsx scripts/content-generator.ts --token "$MEME" --emotion fomo
npx tsx scripts/content-generator.ts --token "$MEME" --emotion greed

# Test different platforms
npx tsx scripts/content-generator.ts --token "$MEME" --platform twitter
npx tsx scripts/content-generator.ts --token "$MEME" --platform telegram
npx tsx scripts/content-generator.ts --token "$MEME" --platform discord

# Test different formats
npx tsx scripts/content-generator.ts --token "$MEME" --format markdown
npx tsx scripts/content-generator.ts --token "$MEME" --format json
npx tsx scripts/content-generator.ts --token "$MEME" --format brief

# Test FUD responses
npx tsx scripts/content-generator.ts --action fud_response --fud price_dump
npx tsx scripts/content-generator.ts --action fud_response --fud whale_dump
npx tsx scripts/content-generator.ts --action fud_response --fud rug_accusation

# Test milestone celebrations
npx tsx scripts/content-generator.ts --action milestone_celebration --milestone 100k
npx tsx scripts/content-generator.ts --action milestone_celebration --milestone 1m

# Run validation tests
npx vitest run scripts/validate-meme-pumper-skill.test.ts
```

## Test Results Log

| Date | Prompt # | Activated? | Response Quality | Notes |
|------|----------|------------|------------------|-------|
|      |          |            |                  |       |

---

**Last Updated:** 2025-11-22
**Test Suite Version:** 1.0.0
**Maintainer:** Claude Code Validation System

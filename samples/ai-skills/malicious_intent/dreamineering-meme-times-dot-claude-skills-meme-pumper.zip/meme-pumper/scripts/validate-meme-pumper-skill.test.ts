#!/usr/bin/env npx tsx
/**
 * Meme Pumper Skill Validation Tests
 * Proves the skill enforcement and validation logic works correctly
 */

import { describe, expect, it } from 'vitest';
import type {
  ContentCalendar,
  MemeBrief,
  RaidKit,
  ViralHook,
} from './content-generator';
import {
  ContentGenerator,
  ENGAGEMENT_TACTICS,
  OutputFormatter,
  VIRAL_HOOKS,
} from './content-generator';

describe('Meme Pumper Skill Validation', () => {
  describe('ContentGenerator', () => {
    const generator = new ContentGenerator();

    describe('generateMemeBrief', () => {
      it('should generate complete meme brief with all required fields', () => {
        const brief = generator.generateMemeBrief({
          token: '$DCAT',
          action: 'meme_brief',
          platform: 'twitter',
          emotion: 'humor',
          days: 7,
          format: 'markdown',
        });

        expect(brief.project).toBe('$DCAT');
        expect(brief.emotion).toBe('humor');
        expect(brief.visual).toBeDefined();
        expect(brief.visual.format).toBeDefined();
        expect(brief.visual.style).toBeDefined();
        expect(brief.visual.keyElements.length).toBeGreaterThan(0);
        expect(brief.copyAngles.length).toBeGreaterThan(0);
        expect(brief.distribution.heroPlatform).toBe('twitter');
        expect(brief.distribution.supportPlatforms.length).toBeGreaterThan(0);
        expect(brief.successMetrics.engagementTarget).toBeDefined();
      });

      it('should customize copy angles based on emotion', () => {
        const humorBrief = generator.generateMemeBrief({
          token: '$TEST',
          action: 'meme_brief',
          platform: 'twitter',
          emotion: 'humor',
          days: 7,
          format: 'markdown',
        });

        const fomoBrief = generator.generateMemeBrief({
          token: '$TEST',
          action: 'meme_brief',
          platform: 'twitter',
          emotion: 'fomo',
          days: 7,
          format: 'markdown',
        });

        expect(humorBrief.copyAngles).not.toEqual(fomoBrief.copyAngles);
        expect(humorBrief.visual.style).not.toBe(fomoBrief.visual.style);
      });

      it('should set support platforms based on hero platform', () => {
        const twitterBrief = generator.generateMemeBrief({
          token: '$TEST',
          action: 'meme_brief',
          platform: 'twitter',
          emotion: 'humor',
          days: 7,
          format: 'markdown',
        });

        expect(twitterBrief.distribution.supportPlatforms).toContain('telegram');
        expect(twitterBrief.distribution.supportPlatforms).toContain('discord');
      });
    });

    describe('generateViralHooks', () => {
      it('should return sorted hooks by effectiveness', () => {
        const hooks = generator.generateViralHooks({
          action: 'viral_hooks',
          platform: 'twitter',
          emotion: 'humor',
          days: 7,
          format: 'markdown',
        });

        expect(hooks.length).toBeGreaterThan(0);

        // Check hooks are sorted by effectiveness (descending)
        for (let i = 1; i < hooks.length; i++) {
          expect(hooks[i - 1].effectiveness).toBeGreaterThanOrEqual(
            hooks[i].effectiveness,
          );
        }
      });

      it('should customize hooks with token symbol when provided', () => {
        const hooks = generator.generateViralHooks({
          token: '$CUSTOM',
          action: 'viral_hooks',
          platform: 'twitter',
          emotion: 'humor',
          days: 7,
          format: 'markdown',
        });

        const hasCustomToken = hooks.some((h) => h.example.includes('$CUSTOM'));
        expect(hasCustomToken).toBe(true);
      });

      it('should include all hook types', () => {
        const hooks = generator.generateViralHooks({
          action: 'viral_hooks',
          platform: 'twitter',
          emotion: 'humor',
          days: 7,
          format: 'markdown',
        });

        const hookTypes = hooks.map((h) => h.type);
        expect(hookTypes).toContain('The Revelation');
        expect(hookTypes).toContain('The Prediction');
        expect(hookTypes).toContain('The Question');
      });
    });

    describe('generateRaidKit', () => {
      it('should generate complete raid kit with 3 waves', () => {
        const kit = generator.generateRaidKit({
          token: '$RAID',
          action: 'raid_kit',
          platform: 'twitter',
          emotion: 'humor',
          days: 7,
          format: 'markdown',
        });

        expect(kit.waves.length).toBe(3);
        expect(kit.waves[0].timing).toBe('T+0');
        expect(kit.waves[1].timing).toBe('T+5min');
        expect(kit.waves[2].timing).toBe('T+15min');
      });

      it('should include materials list', () => {
        const kit = generator.generateRaidKit({
          token: '$RAID',
          action: 'raid_kit',
          platform: 'twitter',
          emotion: 'humor',
          days: 7,
          format: 'markdown',
        });

        expect(kit.materials.memes).toBeGreaterThan(0);
        expect(kit.materials.copyVariations).toBeGreaterThan(0);
        expect(kit.materials.videoClips).toBeGreaterThan(0);
        expect(kit.materials.hashtags.length).toBeGreaterThan(0);
      });

      it('should include token in hashtags', () => {
        const kit = generator.generateRaidKit({
          token: '$DCAT',
          action: 'raid_kit',
          platform: 'twitter',
          emotion: 'humor',
          days: 7,
          format: 'markdown',
        });

        expect(kit.materials.hashtags).toContain('$DCAT');
      });
    });

    describe('generateContentCalendar', () => {
      it('should generate pre-launch calendar for days <= 7', () => {
        const calendar = generator.generateContentCalendar({
          action: 'content_calendar',
          platform: 'twitter',
          emotion: 'humor',
          days: 7,
          format: 'markdown',
        });

        expect(calendar.phase).toBe('pre_launch');
        expect(calendar.days.length).toBeGreaterThan(0);
      });

      it('should include multiple posts per day', () => {
        const calendar = generator.generateContentCalendar({
          action: 'content_calendar',
          platform: 'twitter',
          emotion: 'humor',
          days: 7,
          format: 'markdown',
        });

        const hasMultiplePosts = calendar.days.some((d) => d.posts.length > 1);
        expect(hasMultiplePosts).toBe(true);
      });

      it('should include themes for each day', () => {
        const calendar = generator.generateContentCalendar({
          action: 'content_calendar',
          platform: 'twitter',
          emotion: 'humor',
          days: 7,
          format: 'markdown',
        });

        calendar.days.forEach((day) => {
          expect(day.theme).toBeDefined();
          expect(day.theme.length).toBeGreaterThan(0);
        });
      });
    });

    describe('generateFudResponse', () => {
      it('should generate response for price dump FUD', () => {
        const response = generator.generateFudResponse('price_dump');
        expect(response).toContain('DISCOUNT');
        expect(response.length).toBeGreaterThan(50);
      });

      it('should generate response for whale dump FUD', () => {
        const response = generator.generateFudResponse('whale_dump');
        expect(response).toContain('WHALE');
        expect(response).toContain('sold');
      });

      it('should generate response for rug accusation', () => {
        const response = generator.generateFudResponse('rug_accusation');
        expect(response).toContain('RENOUNCED');
        expect(response).toContain('LOCKED');
      });

      it('should return default response for unknown FUD type', () => {
        const response = generator.generateFudResponse('unknown_fud');
        expect(response.length).toBeGreaterThan(0);
      });
    });

    describe('generateLaunchContent', () => {
      it('should include announcement thread', () => {
        const content = generator.generateLaunchContent({
          token: '$LAUNCH',
          action: 'launch_content',
          platform: 'twitter',
          emotion: 'humor',
          days: 7,
          format: 'markdown',
        });

        expect(content).toContain('ANNOUNCEMENT THREAD');
        expect(content).toContain('Post 1/5');
        expect(content).toContain('$LAUNCH');
      });

      it('should include single posts', () => {
        const content = generator.generateLaunchContent({
          token: '$LAUNCH',
          action: 'launch_content',
          platform: 'twitter',
          emotion: 'humor',
          days: 7,
          format: 'markdown',
        });

        expect(content).toContain('SINGLE POSTS');
        expect(content).toContain('Option A');
        expect(content).toContain('Option B');
      });

      it('should include quote tweet templates', () => {
        const content = generator.generateLaunchContent({
          token: '$LAUNCH',
          action: 'launch_content',
          platform: 'twitter',
          emotion: 'humor',
          days: 7,
          format: 'markdown',
        });

        expect(content).toContain('QUOTE TWEET TEMPLATES');
      });
    });

    describe('generateMilestoneCelebration', () => {
      it('should generate $100k milestone content', () => {
        const content = generator.generateMilestoneCelebration('100k', {
          token: '$MILE',
          action: 'milestone_celebration',
          platform: 'twitter',
          emotion: 'humor',
          days: 7,
          format: 'markdown',
        });

        expect(content).toContain('$MILE');
        expect(content).toContain('$100K');
      });

      it('should generate $1M milestone content', () => {
        const content = generator.generateMilestoneCelebration('1m', {
          token: '$MILE',
          action: 'milestone_celebration',
          platform: 'twitter',
          emotion: 'humor',
          days: 7,
          format: 'markdown',
        });

        expect(content).toContain('$1 MILLION');
      });

      it('should generate holder milestone content', () => {
        const content = generator.generateMilestoneCelebration('1000_holders', {
          token: '$MILE',
          action: 'milestone_celebration',
          platform: 'twitter',
          emotion: 'humor',
          days: 7,
          format: 'markdown',
        });

        expect(content).toContain('1000 HOLDER');
        expect(content).toContain('community');
      });
    });
  });

  describe('OutputFormatter', () => {
    const formatter = new OutputFormatter();
    const generator = new ContentGenerator();

    it('should format as JSON when requested', () => {
      const brief = generator.generateMemeBrief({
        token: '$TEST',
        action: 'meme_brief',
        platform: 'twitter',
        emotion: 'humor',
        days: 7,
        format: 'json',
      });

      const output = formatter.format(brief, {
        token: '$TEST',
        action: 'meme_brief',
        platform: 'twitter',
        emotion: 'humor',
        days: 7,
        format: 'json',
      });

      const parsed = JSON.parse(output);
      expect(parsed.project).toBe('$TEST');
    });

    it('should format meme brief as markdown', () => {
      const brief = generator.generateMemeBrief({
        token: '$TEST',
        action: 'meme_brief',
        platform: 'twitter',
        emotion: 'humor',
        days: 7,
        format: 'markdown',
      });

      const output = formatter.format(brief, {
        token: '$TEST',
        action: 'meme_brief',
        platform: 'twitter',
        emotion: 'humor',
        days: 7,
        format: 'markdown',
      });

      expect(output).toContain('# MEME BRIEF');
      expect(output).toContain('## Narrative');
      expect(output).toContain('## Copy Angles');
    });

    it('should format as brief when requested', () => {
      const brief = generator.generateMemeBrief({
        token: '$TEST',
        action: 'meme_brief',
        platform: 'twitter',
        emotion: 'humor',
        days: 7,
        format: 'brief',
      });

      const output = formatter.format(brief, {
        token: '$TEST',
        action: 'meme_brief',
        platform: 'twitter',
        emotion: 'humor',
        days: 7,
        format: 'brief',
      });

      expect(output).toContain('MEME BRIEF');
      expect(output.length).toBeLessThan(500); // Brief should be concise
    });

    it('should format viral hooks as markdown', () => {
      const hooks = generator.generateViralHooks({
        action: 'viral_hooks',
        platform: 'twitter',
        emotion: 'humor',
        days: 7,
        format: 'markdown',
      });

      const output = formatter.format(hooks, {
        action: 'viral_hooks',
        platform: 'twitter',
        emotion: 'humor',
        days: 7,
        format: 'markdown',
      });

      expect(output).toContain('VIRAL HOOK LIBRARY');
      expect(output).toContain('Effectiveness:');
      expect(output).toContain('Template:');
    });

    it('should format raid kit as markdown', () => {
      const kit = generator.generateRaidKit({
        token: '$RAID',
        action: 'raid_kit',
        platform: 'twitter',
        emotion: 'humor',
        days: 7,
        format: 'markdown',
      });

      const output = formatter.format(kit, {
        token: '$RAID',
        action: 'raid_kit',
        platform: 'twitter',
        emotion: 'humor',
        days: 7,
        format: 'markdown',
      });

      expect(output).toContain('RAID KIT');
      expect(output).toContain('Waves');
      expect(output).toContain('Materials Provided');
      expect(output).toContain('Rules of Engagement');
    });

    it('should format content calendar as markdown', () => {
      const calendar = generator.generateContentCalendar({
        action: 'content_calendar',
        platform: 'twitter',
        emotion: 'humor',
        days: 7,
        format: 'markdown',
      });

      const output = formatter.format(calendar, {
        action: 'content_calendar',
        platform: 'twitter',
        emotion: 'humor',
        days: 7,
        format: 'markdown',
      });

      expect(output).toContain('CONTENT CALENDAR');
      expect(output).toContain('Day');
      expect(output).toContain('UTC');
    });
  });

  describe('VIRAL_HOOKS Library', () => {
    it('should have hooks with valid effectiveness scores', () => {
      VIRAL_HOOKS.forEach((hook) => {
        expect(hook.effectiveness).toBeGreaterThanOrEqual(1);
        expect(hook.effectiveness).toBeLessThanOrEqual(10);
      });
    });

    it('should have non-empty templates', () => {
      VIRAL_HOOKS.forEach((hook) => {
        expect(hook.template.length).toBeGreaterThan(0);
        expect(hook.example.length).toBeGreaterThan(0);
      });
    });

    it('should have unique hook types', () => {
      const types = VIRAL_HOOKS.map((h) => h.type);
      const uniqueTypes = [...new Set(types)];
      expect(types.length).toBe(uniqueTypes.length);
    });
  });

  describe('ENGAGEMENT_TACTICS', () => {
    it('should have all required tactics', () => {
      expect(ENGAGEMENT_TACTICS.typoStrategy).toBeDefined();
      expect(ENGAGEMENT_TACTICS.incompleteInfo).toBeDefined();
      expect(ENGAGEMENT_TACTICS.polarization).toBeDefined();
      expect(ENGAGEMENT_TACTICS.numberPsychology).toBeDefined();
      expect(ENGAGEMENT_TACTICS.timePressure).toBeDefined();
      expect(ENGAGEMENT_TACTICS.socialProof).toBeDefined();
    });

    it('should have examples for each tactic', () => {
      Object.values(ENGAGEMENT_TACTICS).forEach((tactic) => {
        expect(tactic.name).toBeDefined();
        expect(tactic.description).toBeDefined();
        expect(tactic.example).toBeDefined();
      });
    });
  });

  describe('Emotion-Based Content', () => {
    const generator = new ContentGenerator();

    const emotions = [
      'humor',
      'greed',
      'belonging',
      'rebellion',
      'nostalgia',
      'fomo',
      'schadenfreude',
    ] as const;

    emotions.forEach((emotion) => {
      it(`should generate valid brief for ${emotion} emotion`, () => {
        const brief = generator.generateMemeBrief({
          token: '$TEST',
          action: 'meme_brief',
          platform: 'twitter',
          emotion,
          days: 7,
          format: 'markdown',
        });

        expect(brief.emotion).toBe(emotion);
        expect(brief.visual.style).toBeDefined();
        expect(brief.visual.keyElements.length).toBeGreaterThan(0);
        expect(brief.copyAngles.length).toBe(3);
      });
    });
  });

  describe('Platform-Specific Content', () => {
    const generator = new ContentGenerator();

    const platforms = [
      'twitter',
      'telegram',
      'discord',
      'reddit',
      'tiktok',
    ] as const;

    platforms.forEach((platform) => {
      it(`should generate valid brief for ${platform}`, () => {
        const brief = generator.generateMemeBrief({
          token: '$TEST',
          action: 'meme_brief',
          platform,
          emotion: 'humor',
          days: 7,
          format: 'markdown',
        });

        expect(brief.distribution.heroPlatform).toBe(platform);
        expect(brief.distribution.supportPlatforms).toBeDefined();
        expect(brief.distribution.supportPlatforms).not.toContain(platform);
        expect(brief.distribution.launchTime).toContain('UTC');
      });
    });
  });

  describe('Content Quality Validation', () => {
    const generator = new ContentGenerator();

    it('should generate copy angles containing token symbol', () => {
      const brief = generator.generateMemeBrief({
        token: '$QUALITY',
        action: 'meme_brief',
        platform: 'twitter',
        emotion: 'humor',
        days: 7,
        format: 'markdown',
      });

      const hasTokenInCopy = brief.copyAngles.every((angle) =>
        angle.includes('$QUALITY'),
      );
      expect(hasTokenInCopy).toBe(true);
    });

    it('should generate actionable raid instructions', () => {
      const kit = generator.generateRaidKit({
        token: '$RAID',
        action: 'raid_kit',
        platform: 'twitter',
        emotion: 'humor',
        days: 7,
        format: 'markdown',
      });

      kit.waves.forEach((wave) => {
        expect(wave.actions.length).toBeGreaterThan(0);
        expect(wave.participants).toBeDefined();
      });
    });

    it('should generate calendar with progressive themes', () => {
      const calendar = generator.generateContentCalendar({
        action: 'content_calendar',
        platform: 'twitter',
        emotion: 'humor',
        days: 7,
        format: 'markdown',
      });

      // Themes should progress logically
      const themes = calendar.days.map((d) => d.theme);
      expect(themes[0]).toContain('Mystery');
    });
  });
});
